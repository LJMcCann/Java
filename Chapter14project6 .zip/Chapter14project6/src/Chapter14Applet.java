import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.*;


public class Chapter14Applet extends JApplet {

	//Set Shape Dimensions
	int SquareLength = 100;
	int SquareWidth  = 100;
	int CircleWidth    = 60;
	int CircleHight    = 60;
	
	//Find Coords for Square for Circles
	int SquareCoordX;
	int SquareCoordY;
	
	//Build Circle or dont
	boolean Box11 = false;
	boolean Box12 = false;
	boolean Box13 = false;
	boolean Box14 = false;
	
	boolean Box21 = false;
	boolean Box22 = false;
	boolean Box23 = false;
	boolean Box24 = false;
	
	boolean Box31 = false;
	boolean Box32 = false;
	boolean Box33 = false;
	boolean Box34 = false;
	
	boolean Box41 = false;
	boolean Box42 = false;
	boolean Box43 = false;
	boolean Box44 = false;
	
	//Initializer
	public void init(){
		
		getContentPane().setBackground(Color.white);
		addMouseListener(new MyMouseListener());
		
		this.setSize(new Dimension(400, 400));
		
	
	}
	//Paint Program
	public void paint(Graphics g){
		super.paint(g);
		
		DrawGrid(g);
		
		if (Box11){
			DrawCircle(g, 20, 20);
		}
		if (Box12){
			DrawCircle(g, 20, 120);
		}
		if (Box13){
			DrawCircle(g, 20, 220);
		}
		if (Box14){
			DrawCircle(g, 20, 320);
		}
		if (Box21){
			DrawCircle(g, 120, 20);
		}
		if (Box22){
			DrawCircle(g, 120, 120);
		}
		if (Box23){
			DrawCircle(g, 120, 220);
		}
		if (Box24){
			DrawCircle(g, 120, 320);
		}
		if (Box31){
			DrawCircle(g, 220, 20);
		}
		if (Box32){
			DrawCircle(g, 220, 120);
		}
		if (Box33){
			DrawCircle(g, 220, 220);
		}
		if (Box34){
			DrawCircle(g, 220, 320);
		}
		if (Box41){
			DrawCircle(g, 320, 20);
		}
		if (Box42){
			DrawCircle(g, 320, 120);
		}
		if (Box43){
			DrawCircle(g, 320, 220);
		}
		if (Box44){
			DrawCircle(g, 320, 320);
		}
	}
	
	//Draw GridPattern
	public void DrawGrid(Graphics g){
		
		
		//Draw first row
		g.drawRect(1, 1, SquareWidth, SquareLength);
		g.drawRect(100, 1, SquareWidth, SquareLength);
		g.drawRect(200, 1, SquareWidth, SquareLength);
		g.drawRect(300, 1, SquareWidth, SquareLength);
		
		//Draw Second row
		g.drawRect(1, 100, SquareWidth, SquareLength);
		g.drawRect(100, 100, SquareWidth, SquareLength);
		g.drawRect(200, 100, SquareWidth, SquareLength);
		g.drawRect(300, 100, SquareWidth, SquareLength);
		
		//Draw third row
		g.drawRect(1, 200, SquareWidth, SquareLength);
		g.drawRect(100, 200, SquareWidth, SquareLength);
		g.drawRect(200, 200, SquareWidth, SquareLength);
		g.drawRect(300, 200, SquareWidth, SquareLength);
		
		//Draw Fourth row
		g.drawRect(1, 300, SquareWidth, SquareLength);
		g.drawRect(100, 300, SquareWidth, SquareLength);
		g.drawRect(200, 300, SquareWidth, SquareLength);
		g.drawRect(300, 300, SquareWidth, SquareLength);
		
		
	}
	
	
	//Mouse Listener
	private class MyMouseListener extends MouseAdapter{
		
		public void mouseClicked(MouseEvent e){
			
			SquareCoordX = e.getX();
			SquareCoordY = e.getY();
			
			//Simplify Coords
			GetSquare(SquareCoordX, SquareCoordY);
			
			
			//Should draw Circle Or Not
			if (SquareCoordX == 1){
				if (SquareCoordY == 1){
					if (Box11){
						Box11 = false;
					}else if (!Box11){
						Box11 = true;
					}
				}
				if (SquareCoordY == 2){
					if (Box12){
						Box12 = false;
					}else if (!Box12){
						Box12 = true;
					}
				}
				if (SquareCoordY == 3){
					if (Box13){
						Box13 = false;
					}else if (!Box13){
						Box13 = true;
					}
				}
				if (SquareCoordY == 4){
					if (Box14){
						Box14 = false;
					}else if (!Box14){
						Box14 = true;
					}
				}
				
			}
			if (SquareCoordX == 2){
				if (SquareCoordY == 1){
					if (Box21){
						Box21 = false;
					}else if (!Box21){
						Box21 = true;
					}
				}
				if (SquareCoordY == 2){
					if (Box22){
						Box22 = false;
					}else if (!Box22){
						Box22 = true;
					}
				}
				if (SquareCoordY == 3){
					if (Box23){
						Box23 = false;
					}else if (!Box23){
						Box23 = true;
					}
				}
				if (SquareCoordY == 4){
					if (Box24){
						Box24 = false;
					}else if (!Box24){
						Box24 = true;
					}
				}
				
			}
			if (SquareCoordX == 3){
				if (SquareCoordY == 1){
					if (Box31){
						Box31 = false;
					}else if (!Box31){
						Box31 = true;
					}
				}
				if (SquareCoordY == 2){
					if (Box32){
						Box32 = false;
					}else if (!Box32){
						Box32 = true;
					}
				}
				if (SquareCoordY == 3){
					if (Box33){
						Box33 = false;
					}else if (!Box33){
						Box33 = true;
					}
				}
				if (SquareCoordY == 4){
					if (Box34){
						Box34 = false;
					}else if (!Box34){
						Box34 = true;
					}
				}
				
			}
			if (SquareCoordX == 4){
				if (SquareCoordY == 1){
					if (Box41){
						Box41 = false;
					}else if (!Box41){
						Box41 = true;
					}
				}
				if (SquareCoordY == 2){
					if (Box42){
						Box42 = false;
					}else if (!Box42){
						Box42 = true;
					}
				}
				if (SquareCoordY == 3){
					if (Box43){
						Box43 = false;
					}else if (!Box43){
						Box43 = true;
					}
				}
				if (SquareCoordY == 4){
					if (Box44){
						Box44 = false;
					}else if (!Box44){
						Box44 = true;
					}
				}
				
			}
		
			repaint();
		}
		
		
		
	}
	public void GetSquare(int x, int y){
		//get x value of square	from basic coords from click event
		if (x <= 100){
			SquareCoordX = 1;
		}
		if (x > 100 && x <= 200){
			SquareCoordX = 2; 
		}
		if (x > 200 && x <= 300){
			SquareCoordX = 3;
		}
		if (x > 300 && x <= 400){
			SquareCoordX = 4;
		}
		//get y value of square
		if (y <= 100){
			SquareCoordY = 1;
		}
		if (y > 100 && y <= 200){
			SquareCoordY = 2; 
		}
		if (y > 200 && y <= 300){
			SquareCoordY = 3;
		}
		if (y > 300 && y <= 400){
			SquareCoordY = 4;
		}
		
		
	}
	
	//Draws circle when needed
	public void DrawCircle(Graphics g, int X, int Y){
		g.setColor(Color.black);
		g.fillOval(X, Y, CircleWidth, CircleHight);
		
	}
	
	//remove circle when needed
	public void EraseCircle(Graphics g , int X, int Y){
		
		g.setColor(Color.white);
		g.fillOval(X, Y, CircleWidth, CircleHight);
	}
	
	
}
