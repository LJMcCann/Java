import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.File;


public class Chapter14Project9 extends JFrame {
	
	private final int MAX_IMAGES = 10; 
	
	//panels
    private JPanel SlidesPanel;           
    private JPanel ControlPanel;
    //labels
    private JLabel SlideLabel;
    //button
    private JButton imageSelect;         
    private JButton delaySetting;        
    private JButton start;        
    private JButton stop;
    //files
    private JFileChooser fileFinder;
    //timer
    private Timer timer;               
    private int Delay = 1000;
    //images
    private ImageIcon[] imageArray;        
    private int numImages = 0;       
    private int currentImage = 0;
	
    
    
    public Chapter14Project9(){
    	
    	setTitle("MacroFirm Powerpoint");
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	setLayout(new BorderLayout());
    	
    	buildSlidesPanel();
    	buildControlPanel();
    	
    	add(SlidesPanel, BorderLayout.CENTER);
    	add(ControlPanel, BorderLayout.SOUTH);   
        
    	fileFinder = new JFileChooser(".");
        
    	timer = new Timer(Delay, new TimerListener());
        
    	imageArray = new ImageIcon[MAX_IMAGES];
    	
    	pack();
        setVisible(true);
    }
    
    private void buildSlidesPanel()
    {
         
         SlidesPanel = new JPanel();

         
         SlideLabel = new JLabel();

         
         SlidesPanel.add(SlideLabel);
    }

    
    private void buildControlPanel()
    {
    
         ControlPanel = new JPanel();
     
         imageSelect = new JButton("Add Image");
         imageSelect.setMnemonic(KeyEvent.VK_A);
         imageSelect.setToolTipText("Click here to add an image.");
         
    
         delaySetting = new JButton("Set Time Delay");
         delaySetting.setMnemonic(KeyEvent.VK_T);
         delaySetting.setToolTipText("Click here to set the time delay.");

    
         start = new JButton("Start");
         start.setMnemonic(KeyEvent.VK_S);
         start.setToolTipText("Click here to start the slide show.");
  
    
         stop = new JButton("Stop");
         stop.setMnemonic(KeyEvent.VK_P);
         stop.setToolTipText("Click here to stop the slide show.");

    
         imageSelect.addActionListener(new imageSelectListener());
         delaySetting.addActionListener(new delaySettingListener());
         start.addActionListener(new startListener());
         stop.addActionListener(new stopListener());
         
    
         ControlPanel.add(imageSelect);
         ControlPanel.add(delaySetting);
         ControlPanel.add(start);
         ControlPanel.add(stop);
    }
    private class imageSelectListener implements ActionListener
    {
    

         public void actionPerformed(ActionEvent e)
         {
              File selectedFile;     // To reference the selected image file
              ImageIcon thisImage;   // To read the image from the file
              String filename;       // To hold the name and path of the file
              int fileFinderStatus; // Indicates status of the open dialog box
              
              if (numImages >= MAX_IMAGES)
                 JOptionPane.showMessageDialog(null, "The maximum number of imageArray " +
                                                     "have been selected.");
              else
              {              
    
                 fileFinderStatus = fileFinder.showOpenDialog(Chapter14Project9.this);

                 if (fileFinderStatus == JFileChooser.APPROVE_OPTION)
                 {
    
                   selectedFile = fileFinder.getSelectedFile();

    
                   filename = selectedFile.getPath();

    
                   thisImage = new ImageIcon(filename);

    
                   imageArray[numImages] = thisImage;
                   numImages++;
                 }
              }
         }
    }
    
    private class delaySettingListener implements ActionListener
    {
       

       public void actionPerformed(ActionEvent e)
       {
          String input = JOptionPane.showInputDialog("Enter the time delay (in seconds).");
          Delay = Integer.parseInt(input) * 1000;
          timer.setDelay(Delay);
       }
    }
    
    private class startListener implements ActionListener
    {
       
    
       public void actionPerformed(ActionEvent e)
       {
          timer.start();
       }
    }
    
    private class stopListener implements ActionListener
    {
       
    
       public void actionPerformed(ActionEvent e)
       {
          timer.stop();
       }
    }

    
    
    private class TimerListener implements ActionListener
    {
      
    
       public void actionPerformed(ActionEvent e)
       {
          setTitle("Image " + String.valueOf(currentImage+1));
          
          SlideLabel.setIcon(imageArray[currentImage]);

          
          pack();

          
          if (currentImage < (numImages - 1))
             currentImage++;
          else
             currentImage = 0;
       }
    }
    
    
    public static void main(String[] args)
    {
       Chapter14Project9 CP = new Chapter14Project9();
    }
    
    
}
