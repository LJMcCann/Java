import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;


public class resturantController extends JFrame{
	
	public JMenuBar menuBar;
	public JMenu Menu;
	public JMenu dbmanage;
	public JMenuItem Home;
	public JMenuItem reports;
	public JMenuItem dbInsert;
	public JMenuItem dbSearch;
	public JMenuItem dbUpdate;
	public JMenuItem dbDelete;
	
	public JPanel tablesPanel;
	public JPanel buttonsPanel;
	
	public JButton ViewMenu;
	public JButton adminLogin;
	public JButton adminLogout;
	public JLabel Spacer1;
	public JLabel Spacer2;
	public JLabel Spacer3;
	public JLabel Spacer4;
	
	int logcheck = 0;
	
	public int dayid = 1;
	
	public resturantController(){
		
		
		setTitle("Coffeshop Controller");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 700);
		
		buildMenuBar();
		buildTablesPanel();
		buildButtonsPanel();
		
		setLayout(new BorderLayout());
		
		add(buttonsPanel, BorderLayout.WEST);
		add(tablesPanel, BorderLayout.CENTER);
		
		setVisible(true);

		
	}
	
	public void buildMenuBar(){
		
		menuBar = new JMenuBar();
		Menu = new JMenu("Menu");
		dbmanage = new JMenu("Database Manager");
		Home = new JMenuItem("Home");
		
		dbInsert = new JMenuItem("Inserts");
		dbSearch = new JMenuItem("Searches");
		dbUpdate = new JMenuItem("Updates");
		dbDelete = new JMenuItem("Deletes");
		
		Home.addActionListener(new MenuListener());
		dbInsert.addActionListener(new MenuListener());
		dbSearch.addActionListener(new MenuListener());
		dbUpdate.addActionListener(new MenuListener());
		dbDelete.addActionListener(new MenuListener());
		
		dbmanage.add(dbInsert);
		dbmanage.add(dbSearch);
		dbmanage.add(dbUpdate);
		dbmanage.add(dbDelete);
		
		Menu.add(Home);
		
		
		menuBar.add(Menu);
		menuBar.add(dbmanage);
		
		dbmanage.setEnabled(false);
		
		setJMenuBar(menuBar);
		
		
	}
	
	private class MenuListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			String ActionGame = e.getActionCommand();
			
			
			if (ActionGame.equals("Home")){
				resturantController rcl = new resturantController();
				rcl.setVisible(true);
			}else if (ActionGame.equals("Inserts")){
				dbinsertsController dbi = new dbinsertsController();
				dbi.setVisible(true);
			}
			else if (ActionGame.equals("Searches")){
				dbsearchsController dbs = new dbsearchsController();
				dbs.setVisible(true);
			}
			else if (ActionGame.equals("Updates")){
				dbupdateController dbu = new dbupdateController();
				dbu.setVisible(true);
			}
			else if (ActionGame.equals("Deletes")){
				dbdeleteController dbd = new dbdeleteController();
				dbd.setVisible(true);
			}
			
			
			
		}
	}
	
	public void buildButtonsPanel(){
		buttonsPanel = new JPanel();
		ViewMenu = new JButton("View Menu");
		ViewMenu.addActionListener(new RestMenuListener());
		adminLogin = new JButton("Admin Login");
		adminLogin.setSize(100, 180);
		adminLogin.addActionListener(new LoginListener());
		adminLogout = new JButton("Admin Logout");
		adminLogout.setSize(100, 180);
		adminLogout.addActionListener(new LogoutListener());
		
		Spacer1 = new JLabel();
		Spacer2 = new JLabel();
		Spacer3 = new JLabel();
		Spacer4 = new JLabel();
		
		buttonsPanel.setSize(200, 640);
		
		buttonsPanel.setLayout(new GridLayout(7, 1));
		
		buttonsPanel.add(ViewMenu);
		buttonsPanel.add(Spacer1);
		buttonsPanel.add(Spacer2);
		buttonsPanel.add(Spacer3);
		buttonsPanel.add(Spacer4);
		buttonsPanel.add(adminLogin);
		buttonsPanel.add(adminLogout);
		
	}
	
	private class LoginListener implements ActionListener{

		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JPanel loginpanel = new JPanel();
			JTextField logname = new JTextField(15);
			JTextField logpass = new JTextField(15);
			JLabel uLabel = new JLabel("Username");
			JLabel password = new JLabel("Password");
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			loginpanel.add(uLabel);
			loginpanel.add(logname);
			loginpanel.add(password);
			loginpanel.add(logpass);
			
			JOptionPane.showMessageDialog(null, loginpanel);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				loginCheck(conn, logname.getText(), logpass.getText());
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	public void loginCheck(Connection conn, String name, String pass) throws SQLException{
		
		ResultSet Query = logins(conn);
		
		String Username = name;
		String Password = pass;
		
		
		
		
		if(Username.equals("Invalid")){
			Username = "Invalid";
		}
		if(Password.equals("")){
			Password = "Invalid";
		}
		
		while (Query.next()){
			
			if(Username.equals(Query.getString("userUname")) && Password.equals(Query.getString("userPassword"))){
				logcheck = 1;
			}
			
		}
		if(logcheck == 1){
			System.out.println("It works");
			JOptionPane.showMessageDialog(null, "Login Successful");
			dbmanage.setEnabled(true);
		}else{
			JOptionPane.showMessageDialog(null, "Username or Password was Incorrect");
		}
		
	}
	
	public ResultSet logins(Connection conn) throws SQLException{
		ResultSet Tables;
		String sqlTable = "SELECT * FROM usersDB";
		PreparedStatement prepStmt = conn.prepareStatement(sqlTable);
		Tables = prepStmt.executeQuery();
		
		return Tables;
		
	}

	private class LogoutListener implements ActionListener{

		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			logcheck = 0;
			JOptionPane.showMessageDialog(null, "Logout Successful");
			dbmanage.setEnabled(false);
		}
		
	}
	
	private class RestMenuListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			JPanel MenuPanel = new JPanel();
			
			MenuPanel.setLayout(new GridLayout(4, 1));
			
			JTable drinkTable = new JTable();
			JTable foodsTable = new JTable();
			JLabel DrinkTitle = new JLabel("Drinks");
			JLabel FoodsTitle = new JLabel("Food");
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				String[] drinkHead = {"Drink", "Price"};
				String[] foodHead = {"Food", "Price"};
				String[][] rawMenu = FillMenu(conn);
				String[][] rawDrink = new String[rawMenu.length][2];
				String[][] rawFood = new String[rawMenu.length][2];
				int drinkcount=0;
				int foodcount=0;
				for(int x = 0; x < rawMenu.length; x++){
					
					if(rawMenu[x][3].equals("Drinks")){
						rawDrink[drinkcount][0] = rawMenu[x][1];
						rawDrink[drinkcount][1] = rawMenu[x][2];
						System.out.println(rawDrink[drinkcount][0]+ rawDrink[drinkcount][1]);
						drinkcount++;
					}else if(rawMenu[x][3].equals("Food")){
						rawFood[foodcount][0] = rawMenu[x][1];
						rawFood[foodcount][1] = rawMenu[x][2];
						System.out.println(rawFood[foodcount][0]+ rawFood[foodcount][1]);
						foodcount++;
					}
				}
				drinkTable = new JTable(rawDrink, drinkHead);
				foodsTable = new JTable(rawFood, foodHead);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			MenuPanel.add(DrinkTitle);
			MenuPanel.add(drinkTable);
			MenuPanel.add(FoodsTitle);
			MenuPanel.add(foodsTable);
			
			JOptionPane.showMessageDialog(null, MenuPanel);
			
			
		}
		
	}
	
	public void buildTablesPanel() {
		String Tables[][] = new String[0][4];
		
		tablesPanel = new JPanel();
		tablesPanel.setSize(800, 640);
		
		
		final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
		
		Connection conn;
		
		try {
			conn = DriverManager.getConnection(DBurl);
			Tables = FillTables(conn);
			
			tablesPanel.setLayout(new GridLayout(4, 4));
			
			for(int x = 0; x < Tables.length; x++){
				
				JButton Table = new JButton("Table " + (x+1));
				
				Table.addActionListener(new TableListener());
				
				if(Boolean.parseBoolean(Tables[x][3]) == true){
					Table.setBackground(Color.GRAY);
				}
				if(Boolean.parseBoolean(Tables[x][3]) == false){
					Table.setBackground(Color.GRAY);
				}
				
				tablesPanel.add(Table);
				
			}

			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}
	
	private class TableListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			String tablestring = arg0.getActionCommand();
			JPanel inventoryPanel = new JPanel();
			JTextField ormenu = new JTextField(7);
			String tableNumber = String.valueOf(tablestring.charAt(6));
			inventoryPanel.add(new JLabel("Order Menu Item: "));
			inventoryPanel.add(ormenu);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				
				JOptionPane.showMessageDialog(null, inventoryPanel);
				InsertOrder(conn, tableNumber, dayid, ormenu.getText());
				
				dayid++;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	public void InsertOrder(Connection conn, String tnum, int dayid, String ormenu)throws SQLException{
		System.out.println("Insert for table " + tnum + " Day ID " + dayid + " Menu Item " + ormenu);
		
		String sqlEmpInsert = "INSERT INTO OrdersDB (orderDayID, orderTable, orderMenuItem) "
				+ "VALUES (?, ?, ?)";

		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);

		prepStmt.setInt(1, dayid);
		prepStmt.setString(2, tnum);
		prepStmt.setString(3, ormenu);

		prepStmt.executeUpdate();
		prepStmt.close();
		
		
	}
	
	
	public String[][] FillTables(Connection conn){
		String[][] tablelist = null;
		try {
			ResultSet Tables = GETTABLES(conn);
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> nums = new ArrayList<Integer>();
			ArrayList<Integer> seats = new ArrayList<Integer>();
			ArrayList<String> used = new ArrayList<String>();
			
			while (Tables.next()){
				
				ids.add(Tables.getInt("tableID"));
				nums.add(Tables.getInt("tableNumber"));
				seats.add(Tables.getInt("tableSeats"));
				used.add(Tables.getString("tableOpen"));
				
				currentRow++;
			}
			tablelist = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				tablelist[x][0] = String.valueOf(ids.get(x));
				tablelist[x][1] = String.valueOf(nums.get(x));
				tablelist[x][2] = String.valueOf(seats.get(x));
				tablelist[x][3] = String.valueOf(used.get(x));
				
			}
					
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return tablelist;
		
		
	}
	
	public String[][] FillMenu(Connection conn){
		String[][] menuList = null;
		try{
			ResultSet menu = GETMENU(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Double> price = new ArrayList<Double>();
			ArrayList<String> cata = new ArrayList<String>();
			
			while (menu.next()){
				
				ids.add(menu.getInt("menuID"));
				names.add(menu.getString("menuName"));
				price.add(menu.getDouble("menuPrice"));
				cata.add(menu.getString("menuCatagory"));
				
				
				currentRow++;
			}
			menuList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				menuList[x][0] = String.valueOf(ids.get(x));
				menuList[x][1] = String.valueOf(names.get(x));
				menuList[x][2] = String.valueOf(price.get(x));
				menuList[x][3] = String.valueOf(cata.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		
		return menuList;
	}	
	
	public ResultSet GETTABLES(Connection conn) throws SQLException{
		
		ResultSet Tables;
		String sqlTable = "SELECT * FROM tablesDB";
		PreparedStatement prepStmt = conn.prepareStatement(sqlTable);
		Tables = prepStmt.executeQuery();
		
		return Tables;
		
	}
	
	public void UPTABLEUSED(Connection conn, String id, String seats, String trfa) throws SQLException{
		
		System.out.print(seats);
		
		String sqlTable = "UPDATE tablesDB SET tableNumber = ?, tableSeats = ?, tableOpen = ? WHERE tableID = ?";
		PreparedStatement prepStmt = conn.prepareStatement(sqlTable);
		
		prepStmt.setString(1, id);
		prepStmt.setString(2, seats);
		prepStmt.setString(3, trfa);
		prepStmt.setString(4, id);
		
		
		prepStmt.executeUpdate();
	}
	
	public ResultSet GETMENU(Connection conn) throws SQLException{
		ResultSet Menu;
		
		String sqlTable = "SELECT * FROM menuDB";
		PreparedStatement prepStmt = conn.prepareStatement(sqlTable);
		Menu = prepStmt.executeQuery();
		return Menu;
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			resturantController rcl = new resturantController();
	}

}
