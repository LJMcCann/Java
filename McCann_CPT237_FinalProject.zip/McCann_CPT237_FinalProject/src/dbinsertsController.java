import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;


public class dbinsertsController extends JFrame{

	public JMenuBar menuBar;
	public JMenu Menu;
	public JMenu dbmanage;
	public JMenuItem Home;
	public JMenuItem reports;
	public JMenuItem dbInsert;
	public JMenuItem dbSearch;
	public JMenuItem dbUpdate;
	public JMenuItem dbDelete;
	
	public JLabel adminLabel;
	public JButton adminLogin;
	public JButton adminLogout;
	public JLabel Spacer1;
	public JLabel Spacer2;
	public JLabel Spacer3;
	public JLabel Spacer4;
	
	public JPanel LabelsPanel;
	public JPanel ButtonPanel;
	
	public JButton inventInsert;
	public JButton menuInsert;
	public JButton ordersInsert;
	public JButton tablesInsert;
	public JButton usersInsert;
	
	public dbinsertsController(){
		setTitle("Coffeshop Database Inserts");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1000, 700);
		
		buildMenuBar();
		buildSideBar();
		buildButtonPanel();
		
		setLayout(new BorderLayout());
		
		add(LabelsPanel, BorderLayout.WEST);
		add(ButtonPanel, BorderLayout.EAST);
		
		setVisible(true);
	}
	
	
	public void buildMenuBar(){
		
		menuBar = new JMenuBar();
		Menu = new JMenu("Home");
		dbmanage = new JMenu("Database Manager");
		dbInsert = new JMenuItem("Inserts");
		dbSearch = new JMenuItem("Searchs");
		dbUpdate = new JMenuItem("Updates");
		dbDelete = new JMenuItem("Deletes");
		
		Menu.addActionListener(new MenuBarListener());
		dbInsert.addActionListener(new MenuBarListener());
		dbSearch.addActionListener(new MenuBarListener());
		dbUpdate.addActionListener(new MenuBarListener());
		dbDelete.addActionListener(new MenuBarListener());
		
		dbmanage.add(dbInsert);
		dbmanage.add(dbSearch);
		dbmanage.add(dbUpdate);
		dbmanage.add(dbDelete);
		
		menuBar.add(Menu);
		menuBar.add(dbmanage);
		
		setJMenuBar(menuBar);
		
		
	}
	
	private class MenuBarListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			String ActionGame = e.getActionCommand();
			
			
			if (ActionGame.equals("Home")){
				resturantController rcl = new resturantController();
				rcl.setVisible(true);
			}else if (ActionGame.equals("Inserts")){
				dbinsertsController dbi = new dbinsertsController();
				dbi.setVisible(true);
			}
			else if (ActionGame.equals("Searchs")){
				dbsearchsController dbs = new dbsearchsController();
				dbs.setVisible(true);
			}
			else if (ActionGame.equals("Updates")){
				dbupdateController dbu = new dbupdateController();
				dbu.setVisible(true);
			}
			else if (ActionGame.equals("Deletes")){
				dbdeleteController dbd = new dbdeleteController();
				dbd.setVisible(true);
			}
			
			
			
		}
	}
	
	public void buildSideBar(){
		
		LabelsPanel = new JPanel();
		
		
		adminLogin = new JButton("Admin Login");
		adminLogout = new JButton("Admin Logout");
		adminLabel = new JLabel("Welcome Admin");
		Spacer1 = new JLabel("Database Inserts");
		Spacer2 = new JLabel();
		Spacer3 = new JLabel();
		Spacer4 = new JLabel();
		
		LabelsPanel.setSize(200, 640);
		
		LabelsPanel.setLayout(new GridLayout(7, 1));
		
		LabelsPanel.add(adminLabel);
		LabelsPanel.add(Spacer1);
		LabelsPanel.add(Spacer2);
		LabelsPanel.add(Spacer3);
		LabelsPanel.add(Spacer4);
		
	}
	
	public void buildButtonPanel(){
		
		ButtonPanel = new JPanel();
		
		inventInsert = new JButton("Inventory Insert");
		menuInsert = new JButton("Menu Insert");
		ordersInsert = new JButton("Orders Insert");
		tablesInsert = new JButton("Tables Insert");
		usersInsert = new JButton("Users Insert");
		
		inventInsert.addActionListener(new InventoryListener());
		menuInsert.addActionListener(new MenuListener());
		ordersInsert.addActionListener(new OrdersListener());
		tablesInsert.addActionListener(new TablesListener());
		usersInsert.addActionListener(new UsersListener());
		
		
		ButtonPanel.add(inventInsert);
		ButtonPanel.add(menuInsert);
		ButtonPanel.add(ordersInsert);
		ButtonPanel.add(tablesInsert);
		ButtonPanel.add(usersInsert);
	}
	
	
	private class InventoryListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				InsertInventory(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	private class MenuListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				InsertMenu(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	private class OrdersListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				InsertOrders(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	private class TablesListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				InsertTable(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	private class UsersListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				InsertUsers(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public void InsertInventory(Connection conn) throws SQLException{
 	
		JPanel inPanel = new JPanel();
		JLabel NameLabel = new JLabel("Input Inventory Name: ");
		JLabel QuanLabel = new JLabel("Input Inventory Quantity: ");
		JTextField InsertName = new JTextField(14);
		JTextField InsertQuan = new JTextField(6);
		
		inPanel.add(NameLabel);
		inPanel.add(InsertName);
		inPanel.add(QuanLabel);
		inPanel.add(InsertQuan);
		
		JOptionPane.showMessageDialog(null, inPanel);
		
		String inname;
		String inquant;
		
		inname = InsertName.getText();
		inquant = InsertQuan.getText();
		
		String sqlEmpInsert = "INSERT INTO inventoryDB (inventoryItem, inventoryQuantity) "
							+ "VALUES (?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, inname);
		prepStmt.setString(2, inquant);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}
	public void InsertMenu(Connection conn) throws SQLException{
 		
		JPanel inPanel = new JPanel();
		JLabel NameLabel = new JLabel("Input Item Name: ");
		JLabel PricLabel = new JLabel("Input Item Price: ");
		JLabel CataLabel = new JLabel("Input Item Catagory: ");
		JTextField InsertName = new JTextField(14);
		JTextField InsertPric = new JTextField(6);
		JTextField InsertCata = new JTextField(8);
		
		inPanel.add(NameLabel);
		inPanel.add(InsertName);
		inPanel.add(PricLabel);
		inPanel.add(InsertPric);
		inPanel.add(CataLabel);
		inPanel.add(InsertCata);
		
		JOptionPane.showMessageDialog(null, inPanel);
		
		
		String menuname;
		String menuprice;
		String menucat;
		
		menuname = InsertName.getText();
		menuprice = InsertPric.getText();
		menucat = InsertCata.getText();
		
		String sqlEmpInsert = "INSERT INTO menuDB (menuName, menuPrice, menuCatagory) "
							+ "VALUES (?, ?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		
		prepStmt.setString(1, menuname);
		prepStmt.setString(2, menuprice);
		prepStmt.setString(3, menucat);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}
	public void InsertOrders(Connection conn) throws SQLException{

		JPanel inPanel = new JPanel();
		JLabel DayIDLabel = new JLabel("Input Order DayID: ");
		JLabel TableLabel = new JLabel("Input Order Table: ");
		JLabel MenidLabel = new JLabel("Input Order Menu ID: ");
		JTextField InsertDayID = new JTextField(14);
		JTextField InsertTable = new JTextField(6);
		JTextField InsertMenid = new JTextField(6);
		
		inPanel.add(DayIDLabel);
		inPanel.add(InsertDayID);
		inPanel.add(TableLabel);
		inPanel.add(InsertTable);
		inPanel.add(MenidLabel);
		inPanel.add(InsertMenid);
		
		JOptionPane.showMessageDialog(null, inPanel);
		
		String oDayID;
		String oTable;
		String oMenuItem;
		
		oDayID = InsertDayID.getText();
		oTable = InsertTable.getText();
		oMenuItem = InsertMenid.getText();
		
		String sqlEmpInsert = "INSERT INTO OrdersDB (orderDayID, orderTable, orderMenuItem) "
							+ "VALUES (?, ?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, oDayID);
		prepStmt.setString(2, oTable);
		prepStmt.setString(3, oMenuItem);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}
	public void InsertTable(Connection conn) throws SQLException{
 		
		JPanel inPanel = new JPanel();
		JLabel NumsLabel = new JLabel("Input Table Number: ");
		JLabel SeatLabel = new JLabel("Input Table Seats: ");
		JTextField InsertNums = new JTextField(14);
		JTextField InsertSeat = new JTextField(6);
		
		inPanel.add(NumsLabel);
		inPanel.add(InsertNums);
		inPanel.add(SeatLabel);
		inPanel.add(InsertSeat);
		
		JOptionPane.showMessageDialog(null, inPanel);
		
		String tnumber;
		String tseats;
		String topen = "false";
		
		tnumber = InsertNums.getText();
		tseats = InsertSeat.getText();
		
		String sqlEmpInsert = "INSERT INTO tablesDB (tableNumber, tableSeats, tableOpen) "
							+ "VALUES (?, ?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, tnumber);
		prepStmt.setString(2, tseats);
		prepStmt.setString(3, topen);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}
	public void InsertUsers(Connection conn) throws SQLException{
 		
		JPanel inPanel = new JPanel();
		JLabel NameLabel = new JLabel("Input User's Name: ");
		JLabel PhonLabel = new JLabel("Input User's Phone #: ");
		JLabel PosiLabel = new JLabel("Input User's Position: ");
		JTextField InsertName = new JTextField(14);
		JTextField InsertPhon = new JTextField(12);
		JTextField InsertPosi = new JTextField(8);
		
		inPanel.add(NameLabel);
		inPanel.add(InsertName);
		inPanel.add(PhonLabel);
		inPanel.add(InsertPhon);
		inPanel.add(PosiLabel);
		inPanel.add(InsertPosi);
		
		JOptionPane.showMessageDialog(null, inPanel);
		
		String uname;
		String uphone;
		String uposition;
		
		uname = InsertName.getText();
		uphone = InsertPhon.getText();
		uposition = InsertPosi.getText();
		
		String sqlEmpInsert = "INSERT INTO usersDB (userName, userPhone, userPosition) "
							+ "VALUES (?, ?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, uname);
		prepStmt.setString(2, uphone);
		prepStmt.setString(3, uposition);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		dbinsertsController dbi = new dbinsertsController();

	}


}
