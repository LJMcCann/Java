import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;


public class dbsearchsController extends JFrame{

	public JMenuBar menuBar;
	public JMenu Menu;
	public JMenu dbmanage;
	public JMenuItem Home;
	public JMenuItem reports;
	public JMenuItem dbInsert;
	public JMenuItem dbSearch;
	public JMenuItem dbUpdate;
	public JMenuItem dbDelete;
	
	public JLabel adminLabel;
	public JButton adminLogin;
	public JButton adminLogout;
	public JLabel Spacer1;
	public JLabel Spacer2;
	public JLabel Spacer3;
	public JLabel Spacer4;
	
	public JPanel LabelsPanel;
	public JPanel ButtonPanel;
	
	public JButton inventSearch;
	public JButton menuSearch;
	public JButton ordersSearch;
	public JButton tablesSearch;
	public JButton usersSearch;
	
	public dbsearchsController(){
		setTitle("Coffeshop Database Searches");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1000, 700);
		
		buildMenuBar();
		buildSideBar();
		buildButtonPanel();
		
		setLayout(new BorderLayout());
		
		add(LabelsPanel, BorderLayout.WEST);
		add(ButtonPanel, BorderLayout.EAST);
		
		setVisible(true);
	}
	
	public void buildMenuBar(){
		
		menuBar = new JMenuBar();
		Menu = new JMenu("Menu");
		dbmanage = new JMenu("Database Manager");
		Home = new JMenuItem("Home");
		dbInsert = new JMenuItem("Inserts");
		dbSearch = new JMenuItem("Searches");
		dbUpdate = new JMenuItem("Updates");
		dbDelete = new JMenuItem("Deletes");
		
		Home.addActionListener(new MenuBarListener());
		dbInsert.addActionListener(new MenuBarListener());
		dbSearch.addActionListener(new MenuBarListener());
		dbUpdate.addActionListener(new MenuBarListener());
		dbDelete.addActionListener(new MenuBarListener());
		
		dbmanage.add(dbInsert);
		dbmanage.add(dbSearch);
		dbmanage.add(dbUpdate);
		dbmanage.add(dbDelete);
		
		Menu.add(Home);
		
		menuBar.add(Menu);
		menuBar.add(dbmanage);
		
		
		setJMenuBar(menuBar);
		
		
	}
	
	private class MenuBarListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			String ActionGame = e.getActionCommand();
			
			
			if (ActionGame.equals("Home")){
				resturantController rcl = new resturantController();
				rcl.setVisible(true);
			}else if (ActionGame.equals("Inserts")){
				dbinsertsController dbi = new dbinsertsController();
				dbi.setVisible(true);
			}
			else if (ActionGame.equals("Searches")){
				dbsearchsController dbs = new dbsearchsController();
				dbs.setVisible(true);
			}
			else if (ActionGame.equals("Updates")){
				dbupdateController dbu = new dbupdateController();
				dbu.setVisible(true);
			}
			else if (ActionGame.equals("Deletes")){
				dbdeleteController dbd = new dbdeleteController();
				dbd.setVisible(true);
			}
			
			
			
		}
	}
	
	public void buildSideBar(){
		
		LabelsPanel = new JPanel();
		
		
		adminLogin = new JButton("Admin Login");
		adminLogout = new JButton("Admin Logout");
		adminLabel = new JLabel("Welcome Admin");
		Spacer1 = new JLabel("Database Searches");
		Spacer2 = new JLabel();
		Spacer3 = new JLabel();
		Spacer4 = new JLabel();
		
		LabelsPanel.setSize(200, 640);
		
		LabelsPanel.setLayout(new GridLayout(7, 1));
		
		LabelsPanel.add(adminLabel);
		LabelsPanel.add(Spacer1);
		LabelsPanel.add(Spacer2);
		LabelsPanel.add(Spacer3);
		LabelsPanel.add(Spacer4);
		
	}
	
	public void buildButtonPanel(){
			
		ButtonPanel = new JPanel();
		
		inventSearch = new JButton("Inventory Search");
		menuSearch = new JButton("Menu Search");
		ordersSearch = new JButton("Orders Search");
		tablesSearch = new JButton("Tables Search");
		usersSearch = new JButton("Users Search");
		
		inventSearch.addActionListener(new InventoryListener());
		menuSearch.addActionListener(new MenuListener());
		ordersSearch.addActionListener(new OrdersListener());
		tablesSearch.addActionListener(new TablesListener());
		usersSearch.addActionListener(new UsersListener());
		
		
		ButtonPanel.add(inventSearch);
		ButtonPanel.add(menuSearch);
		ButtonPanel.add(ordersSearch);
		ButtonPanel.add(tablesSearch);
		ButtonPanel.add(usersSearch);
	}

	private class InventoryListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			Connection conn;
			JPanel inventoryPanel = new JPanel();
			String[] tHead = {"ID", "Item", "Quantity"};
			try {
				conn = DriverManager.getConnection(DBurl);
				
				JTextField inid = new JTextField(5);
				JTextField initem = new JTextField(7);
				JTextField inquan = new JTextField(5);
				
				
				inventoryPanel.add(new JLabel("Inventory Item: "));
				inventoryPanel.add(initem);
				inventoryPanel.add(new JLabel("Inventory Quantity: "));
				inventoryPanel.add(inquan);
				
				String[][] SInv = ShowInventory(conn);
				
				JTable inventorytable = new JTable(SInv, tHead);
				
				inventoryPanel.add(inventorytable);
				
				JOptionPane.showMessageDialog(null, inventoryPanel);
				
				String[][] Searched = FillInventory(conn, initem.getText(), inquan.getText());
				JTable tableSearch = new JTable(Searched, tHead);
				
				JOptionPane.showMessageDialog(null, tableSearch);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchInventory(Connection conn) throws SQLException{
 	
		ResultSet SearchTable;
		
		String sqlEmpInsert = "SELECT * FROM inventoryDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] ShowInventory(Connection conn){
		String[][] inventoryList = null;
		try{
			ResultSet inventory = SearchInventory(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Integer> quantity = new ArrayList<Integer>();
			
			
			while (inventory.next()){
				ids.add(inventory.getInt("inventoryID"));
				names.add(inventory.getString("inventoryItem"));
				quantity.add(inventory.getInt("inventoryQuantity"));
				currentRow++;
				
			}
			inventoryList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				inventoryList[x][0] = String.valueOf(ids.get(x));
				inventoryList[x][1] = String.valueOf(names.get(x));
				inventoryList[x][2] = String.valueOf(quantity.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return inventoryList;
	}
	public String[][] FillInventory(Connection conn, String name, String Quan){
		String[][] inventoryList = null;
		try{
			ResultSet inventory = SearchInventory(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Integer> quantity = new ArrayList<Integer>();
			
			String InName = name;
			String InQuant = Quan;
			
			while (inventory.next()){
				
				if (InQuant.equals("")){
					InQuant = "0";
				}
				
				if(InName.equals("") && InQuant.equals("0")){
					ids.add(inventory.getInt("inventoryID"));
					names.add(inventory.getString("inventoryItem"));
					quantity.add(inventory.getInt("inventoryQuantity"));
					currentRow++;
				
				}else if(inventory.getString("inventoryItem").contains(InName) && InQuant.equals("0")){
					ids.add(inventory.getInt("inventoryID"));
					names.add(inventory.getString("inventoryItem"));
					quantity.add(inventory.getInt("inventoryQuantity"));
					currentRow++;
				}else if(InName.equals("") && inventory.getInt("inventoryQuantity") == Integer.parseInt(InQuant)){
					ids.add(inventory.getInt("inventoryID"));
					names.add(inventory.getString("inventoryItem"));
					quantity.add(inventory.getInt("inventoryQuantity"));
					currentRow++;
				}else if(inventory.getInt("inventoryQuantity") == Integer.parseInt(InQuant) && inventory.getString("inventoryItem").contains(InName) && !InName.equals("") && !InQuant.equals("0")){
					ids.add(inventory.getInt("inventoryID"));
					names.add(inventory.getString("inventoryItem"));
					quantity.add(inventory.getInt("inventoryQuantity"));
					currentRow++;
				}
				
				
			}
			inventoryList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				inventoryList[x][0] = String.valueOf(ids.get(x));
				inventoryList[x][1] = String.valueOf(names.get(x));
				inventoryList[x][2] = String.valueOf(quantity.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		return inventoryList;
	}
	
	private class MenuListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel inventoryPanel = new JPanel();
			
			JTextField meName = new JTextField(7);
			JTextField mePrice = new JTextField(5);
			JTextField meCat = new JTextField(7);
			
			String[] tHead = {"ID", "Name", "Price", "Catagory"};
			
			
			inventoryPanel.add(new JLabel("Menu Name: "));
			inventoryPanel.add(meName);
			inventoryPanel.add(new JLabel("Menu Price: "));
			inventoryPanel.add(mePrice);
			inventoryPanel.add(new JLabel("Menu Catagory: "));
			inventoryPanel.add(meCat);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				String [][] menu = ShowMenu(conn);
				
				JTable inventorytable = new JTable(menu, tHead);
				
				inventoryPanel.add(inventorytable);
				
				JOptionPane.showMessageDialog(null, inventoryPanel);
				
				String[][] Searched = FillMenu(conn, meName.getText(), mePrice.getText(), meCat.getText());
				JTable tableSearch = new JTable(Searched, tHead);
				
				JOptionPane.showMessageDialog(null, tableSearch);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchMenu(Connection conn) throws SQLException{
 		
		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM menuDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillMenu(Connection conn, String name, String Price, String Cata){
		String[][] menuList = null;
		try{
			ResultSet menu = SearchMenu(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Double> price = new ArrayList<Double>();
			ArrayList<String> cata = new ArrayList<String>();
			
			String InName = name;
			String InPrice = Price;
			String InCata = Cata;
			
			
			while (menu.next()){
				
				if (InPrice.equals("")){
					InPrice = "0.0";
				}
				
				if(InPrice.equals("0.0") && InName.equals("") && InCata.equals("")){
					ids.add(menu.getInt("menuID"));
					names.add(menu.getString("menuName"));
					price.add(menu.getDouble("menuPrice"));
					cata.add(menu.getString("menuCatagory"));
					currentRow++;
				}else if(InPrice.equals("0.0") && menu.getString("menuName").contains(InName) && menu.getString("menuCatagory").contains(InCata)){
					ids.add(menu.getInt("menuID"));
					names.add(menu.getString("menuName"));
					price.add(menu.getDouble("menuPrice"));
					cata.add(menu.getString("menuCatagory"));
					currentRow++;
				}else if(menu.getDouble("MenuPrice") == Double.parseDouble(InPrice) && menu.getString("menuName").contains(InName) && menu.getString("menuCatagory").contains(InCata)){
					ids.add(menu.getInt("menuID"));
					names.add(menu.getString("menuName"));
					price.add(menu.getDouble("menuPrice"));
					cata.add(menu.getString("menuCatagory"));
					currentRow++;
				}
				
			}
			menuList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				menuList[x][0] = String.valueOf(ids.get(x));
				menuList[x][1] = String.valueOf(names.get(x));
				menuList[x][2] = String.valueOf(price.get(x));
				menuList[x][3] = String.valueOf(cata.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
			
		return menuList;
	}
	public String[][] ShowMenu(Connection conn){
		String[][] menuList = null;
		try{
			ResultSet menu = SearchMenu(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Double> price = new ArrayList<Double>();
			ArrayList<String> cata = new ArrayList<String>();
			
			while (menu.next()){
				ids.add(menu.getInt("menuID"));
				names.add(menu.getString("menuName"));
				price.add(menu.getDouble("menuPrice"));
				cata.add(menu.getString("menuCatagory"));
				currentRow++;
			}
			menuList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				menuList[x][0] = String.valueOf(ids.get(x));
				menuList[x][1] = String.valueOf(names.get(x));
				menuList[x][2] = String.valueOf(price.get(x));
				menuList[x][3] = String.valueOf(cata.get(x));
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
			
		return menuList;
	}
	
	private class OrdersListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel inventoryPanel = new JPanel();
			String[] tHead = {"ID", "DayID", "Table", "MenuItem"};
			
			JTextField ordid = new JTextField(5);
			JTextField ortable = new JTextField(5);
			JTextField ormenu = new JTextField(7);
			
			inventoryPanel.add(new JLabel("Order Day ID: "));
			inventoryPanel.add(ordid);
			inventoryPanel.add(new JLabel("Order Table: "));
			inventoryPanel.add(ortable);
			inventoryPanel.add(new JLabel("Order Menu Item: "));
			inventoryPanel.add(ormenu);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				String [][] menu = ShowOrders(conn);
				
				JTable inventorytable = new JTable(menu, tHead);
				
				inventoryPanel.add(inventorytable);
				
				JOptionPane.showMessageDialog(null, inventoryPanel);
				
				String[][] Searched = FillOrders(conn, ordid.getText(), ortable.getText(), ormenu.getText());
				JTable tableSearch = new JTable(Searched, tHead);
				
				JOptionPane.showMessageDialog(null, tableSearch);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchOrders(Connection conn) throws SQLException{

		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM OrdersDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillOrders(Connection conn, String ordid, String ortable, String ormenu){
		String[][] orderList = null;
		try{
			ResultSet order = SearchOrders(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> dayIds = new ArrayList<Integer>();
			ArrayList<Integer> table = new ArrayList<Integer>();
			ArrayList<Integer> menuitemid = new ArrayList<Integer>();
			
			String orderdayid = ordid;
			String ordertable = ortable;
			String ordermenu = ormenu;
			
			while (order.next()){
				
				
				if(ordertable.equals("")){
					ordertable = "0";
				}
				if(ordermenu.equals("")){
					ordermenu = "0";
				}
				
				
				if(ordertable.equals("0") && ordermenu.equals("0")){
					ids.add(order.getInt("orderID"));
					dayIds.add(order.getInt("orderDayID"));
					table.add(order.getInt("orderTable"));
					menuitemid.add(order.getInt("orderMenuItem"));
					currentRow++;
				}else if(order.getInt("orderTable") == Integer.parseInt(ordertable) && order.getInt("orderMenuItem") == Integer.parseInt(ordermenu)){
					ids.add(order.getInt("orderID"));
					dayIds.add(order.getInt("orderDayID"));
					table.add(order.getInt("orderTable"));
					menuitemid.add(order.getInt("orderMenuItem"));
					currentRow++;
				}else if(order.getInt("orderTable") == Integer.parseInt(ordertable) || order.getInt("orderMenuItem") == Integer.parseInt(ordermenu)){
					ids.add(order.getInt("orderID"));
					dayIds.add(order.getInt("orderDayID"));
					table.add(order.getInt("orderTable"));
					menuitemid.add(order.getInt("orderMenuItem"));
					currentRow++;
				}
			
			}
			orderList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				orderList[x][0] = String.valueOf(ids.get(x));
				orderList[x][1] = String.valueOf(dayIds.get(x));
				orderList[x][2] = String.valueOf(table.get(x));
				orderList[x][3] = String.valueOf(menuitemid.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
			
		return orderList;
	}
	public String[][] ShowOrders(Connection conn){
		String[][] orderList = null;
		try{
			ResultSet order = SearchOrders(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> dayIds = new ArrayList<Integer>();
			ArrayList<Integer> table = new ArrayList<Integer>();
			ArrayList<Integer> menuitemid = new ArrayList<Integer>();
			
			while (order.next()){
				
				ids.add(order.getInt("orderID"));
				dayIds.add(order.getInt("orderDayID"));
				table.add(order.getInt("orderTable"));
				menuitemid.add(order.getInt("orderMenuItem"));
				currentRow++;
			
			}
			orderList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				orderList[x][0] = String.valueOf(ids.get(x));
				orderList[x][1] = String.valueOf(dayIds.get(x));
				orderList[x][2] = String.valueOf(table.get(x));
				orderList[x][3] = String.valueOf(menuitemid.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
			
		return orderList;
	}
	
	
	private class TablesListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel inventoryPanel = new JPanel();
			
			JTextField tnum = new JTextField(5);
			JTextField tseat = new JTextField(5);
			
			String[] tHead = {"ID", "Name", "Price"};
			
			
			inventoryPanel.add(new JLabel("Table Seat #: "));
			inventoryPanel.add(tseat);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				String [][] menu = ShowTable(conn);
				
				JTable inventorytable = new JTable(menu, tHead);
				
				inventoryPanel.add(inventorytable);
				
				JOptionPane.showMessageDialog(null, inventoryPanel);
				
				String[][] Searched = FillTable(conn, tseat.getText());
				JTable tableSearch = new JTable(Searched, tHead);
				
				JOptionPane.showMessageDialog(null, tableSearch);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchTable(Connection conn) throws SQLException{
 		
		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM tablesDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillTable(Connection conn, String Seats){
		String[][] tableList = null;
		try{
			ResultSet table = SearchTable(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> num = new ArrayList<Integer>();
			ArrayList<Integer> seats = new ArrayList<Integer>();
			
			String tableSeat = Seats;
			while (table.next()){
				
				if(tableSeat.equals("0")){
					ids.add(table.getInt("tableID"));
					num.add(table.getInt("tableNumber"));
					seats.add(table.getInt("tableSeats"));
					currentRow++;
				}else if(table.getInt("tableSeats") == Integer.parseInt(tableSeat)){
					ids.add(table.getInt("tableID"));
					num.add(table.getInt("tableNumber"));
					seats.add(table.getInt("tableSeats"));
					currentRow++;
				}
				
			}
			tableList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				tableList[x][0] = String.valueOf(ids.get(x));
				tableList[x][1] = String.valueOf(num.get(x));
				tableList[x][2] = String.valueOf(seats.get(x));

			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return tableList;
	}
	public String[][] ShowTable(Connection conn){
		String[][] tableList = null;
		try{
			ResultSet table = SearchTable(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> num = new ArrayList<Integer>();
			ArrayList<Integer> seats = new ArrayList<Integer>();
			
			while (table.next()){
				
				ids.add(table.getInt("tableID"));
				num.add(table.getInt("tableNumber"));
				seats.add(table.getInt("tableSeats"));
				currentRow++;
			}
			tableList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				tableList[x][0] = String.valueOf(ids.get(x));
				tableList[x][1] = String.valueOf(num.get(x));
				tableList[x][2] = String.valueOf(seats.get(x));

			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return tableList;
	}
	
	
	
	private class UsersListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel inventoryPanel = new JPanel();
			String[] tHead = {"ID", "Name", "Phone", "Position", "Password", "UserName"};
			
			JTextField uname = new JTextField(5);
			JTextField uphone = new JTextField(5);
			JTextField uposit = new JTextField(5);
			
			inventoryPanel.add(new JLabel("User Name: "));
			inventoryPanel.add(uname);
			inventoryPanel.add(new JLabel("User Phone: "));
			inventoryPanel.add(uphone);
			inventoryPanel.add(new JLabel("User Position: "));
			inventoryPanel.add(uposit);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				String [][] menu = ShowUsers(conn);
				
				JTable inventorytable = new JTable(menu, tHead);
				
				inventoryPanel.add(inventorytable);
				
				JOptionPane.showMessageDialog(null, inventoryPanel);
				String[][] Searched = FillUsers(conn, uname.getText(), uphone.getText(), uposit.getText());
				JTable tableSearch = new JTable(Searched, tHead);
				
				JOptionPane.showMessageDialog(null, tableSearch);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchUsers(Connection conn) throws SQLException{
 		
		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM usersDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillUsers(Connection conn, String Name, String Phone, String posit){
		String[][] usersList = null;
		try{
			ResultSet table = SearchUsers(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> name = new ArrayList<String>();
			ArrayList<String> phone = new ArrayList<String>();
			ArrayList<String> position = new ArrayList<String>();
			ArrayList<String> pass = new ArrayList<String>();
			ArrayList<String> Uname = new ArrayList<String>();
			
			
			String username = Name;
			String userphone = Phone;
			String userposition = posit;
			
			while (table.next()){
				
				if(table.getString("userName").contains(username) && table.getString("userPhone").contains(userphone) && table.getString("userPosition").contains(userposition)){
					ids.add(table.getInt("userID"));
					name.add(table.getString("userName"));
					phone.add(table.getString("userPhone"));
					position.add(table.getString("userPosition"));
					pass.add(table.getString("userPassword"));
					Uname.add(table.getString("userUname"));
					currentRow++;
				}
				
				
				
			}
			usersList = new String[currentRow][6];
			
			for(int x = 0; x < currentRow; x++){
				
				usersList[x][0] = String.valueOf(ids.get(x));
				usersList[x][1] = String.valueOf(name.get(x));
				usersList[x][2] = String.valueOf(phone.get(x));
				usersList[x][3] = String.valueOf(position.get(x));
				usersList[x][4] = String.valueOf(pass.get(x));
				usersList[x][5] = String.valueOf(Uname.get(x));

			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return usersList;
	}
	public String[][] ShowUsers(Connection conn){
		String[][] usersList = null;
		try{
			ResultSet table = SearchUsers(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> name = new ArrayList<String>();
			ArrayList<String> phone = new ArrayList<String>();
			ArrayList<String> position = new ArrayList<String>();
			ArrayList<String> pass = new ArrayList<String>();
			ArrayList<String> Uname = new ArrayList<String>();
			
			
			
			while (table.next()){
				
				
				ids.add(table.getInt("userID"));
					name.add(table.getString("userName"));
					phone.add(table.getString("userPhone"));
					position.add(table.getString("userPosition"));
					pass.add(table.getString("userPassword"));
					Uname.add(table.getString("userUname"));
					currentRow++;
				
				
			}
			usersList = new String[currentRow][6];
			
			for(int x = 0; x < currentRow; x++){
				
				usersList[x][0] = String.valueOf(ids.get(x));
				usersList[x][1] = String.valueOf(name.get(x));
				usersList[x][2] = String.valueOf(phone.get(x));
				usersList[x][3] = String.valueOf(position.get(x));
				usersList[x][4] = String.valueOf(pass.get(x));
				usersList[x][5] = String.valueOf(Uname.get(x));

			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return usersList;
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		dbsearchsController dbs = new dbsearchsController();

	}

}
