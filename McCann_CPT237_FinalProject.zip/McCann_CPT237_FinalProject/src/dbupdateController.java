import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;


public class dbupdateController extends JFrame{

	public JMenuBar menuBar;
	public JMenu Menu;
	public JMenu dbmanage;
	public JMenuItem Home;
	public JMenuItem reports;
	public JMenuItem dbInsert;
	public JMenuItem dbSearch;
	public JMenuItem dbUpdate;
	public JMenuItem dbDelete;
	
	public JLabel adminLabel;
	public JButton adminLogin;
	public JButton adminLogout;
	public JLabel Spacer1;
	public JLabel Spacer2;
	public JLabel Spacer3;
	public JLabel Spacer4;
	
	public JPanel LabelsPanel;
	public JPanel ButtonPanel;
	
	public JButton inventUpdate;
	public JButton menuUpdate;
	public JButton ordersUpdate;
	public JButton tablesUpdate;
	public JButton usersUpdate;
	
	public dbupdateController(){
		setTitle("Coffeshop Database Updates");

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setSize(1000, 700);
		
		buildMenuBar();
		buildSideBar();
		buildButtonPanel();
		
		setLayout(new BorderLayout());
		
		add(LabelsPanel, BorderLayout.WEST);
		add(ButtonPanel, BorderLayout.EAST);
		
		setVisible(true);
	}
	
	
	public void buildMenuBar(){
		
		menuBar = new JMenuBar();
		Menu = new JMenu("Menu");
		dbmanage = new JMenu("Database Manager");
		Home = new JMenuItem("Home");
		dbInsert = new JMenuItem("Inserts");
		dbSearch = new JMenuItem("Searches");
		dbUpdate = new JMenuItem("Updates");
		dbDelete = new JMenuItem("Deletes");
		
		Home.addActionListener(new MenuBarListener());
		dbInsert.addActionListener(new MenuBarListener());
		dbSearch.addActionListener(new MenuBarListener());
		dbUpdate.addActionListener(new MenuBarListener());
		dbDelete.addActionListener(new MenuBarListener());
		
		dbmanage.add(dbInsert);
		dbmanage.add(dbSearch);
		dbmanage.add(dbUpdate);
		dbmanage.add(dbDelete);
		
		Menu.add(Home);
		
		menuBar.add(Menu);
		menuBar.add(dbmanage);
		
		
		setJMenuBar(menuBar);
		
		
	}
	
	private class MenuBarListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			String ActionGame = e.getActionCommand();
			
			
			if (ActionGame.equals("Home")){
				resturantController rcl = new resturantController();
				rcl.setVisible(true);
			}else if (ActionGame.equals("Inserts")){
				dbinsertsController dbi = new dbinsertsController();
				dbi.setVisible(true);
			}
			else if (ActionGame.equals("Searches")){
				dbsearchsController dbs = new dbsearchsController();
				dbs.setVisible(true);
			}
			else if (ActionGame.equals("Updates")){
				dbupdateController dbu = new dbupdateController();
				dbu.setVisible(true);
			}
			else if (ActionGame.equals("Deletes")){
				dbdeleteController dbd = new dbdeleteController();
				dbd.setVisible(true);
			}
			
			
			
		}
	}
	
	public void buildSideBar(){
		
		LabelsPanel = new JPanel();
		
		
		adminLogin = new JButton("Admin Login");
		adminLogout = new JButton("Admin Logout");
		adminLabel = new JLabel("Welcome Admin");
		Spacer1 = new JLabel("Database Updates");
		Spacer2 = new JLabel();
		Spacer3 = new JLabel();
		Spacer4 = new JLabel();
		
		LabelsPanel.setSize(200, 640);
		
		LabelsPanel.setLayout(new GridLayout(7, 1));
		
		LabelsPanel.add(adminLabel);
		LabelsPanel.add(Spacer1);
		LabelsPanel.add(Spacer2);
		LabelsPanel.add(Spacer3);
		LabelsPanel.add(Spacer4);
		
	}
	
	public void buildButtonPanel(){
		
		ButtonPanel = new JPanel();
		
		inventUpdate = new JButton("Inventory Update");
		menuUpdate = new JButton("Menu Update");
		ordersUpdate = new JButton("Orders Update");
		tablesUpdate = new JButton("Tables Update");
		usersUpdate = new JButton("Users Update");
		
		inventUpdate.addActionListener(new InventoryListener());
		menuUpdate.addActionListener(new MenuListener());
		ordersUpdate.addActionListener(new OrdersListener());
		tablesUpdate.addActionListener(new TablesListener());
		usersUpdate.addActionListener(new UsersListener());
		
		
		ButtonPanel.add(inventUpdate);
		ButtonPanel.add(menuUpdate);
		ButtonPanel.add(ordersUpdate);
		ButtonPanel.add(tablesUpdate);
		ButtonPanel.add(usersUpdate);
	}
	
	
	private class InventoryListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			
			JPanel InUpOption = new JPanel();
			
			JTextField inid = new JTextField(5);
			JTextField initem = new JTextField(7);
			JTextField inquan = new JTextField(5);
			
			String[] tHead = {"ID", "Item", "Quantity"};
			
			InUpOption.add(new JLabel("Inventory ID: "));
			InUpOption.add(inid);
			InUpOption.add(new JLabel("Inventory Item: "));
			InUpOption.add(initem);
			InUpOption.add(new JLabel("Inventory Quantity: "));
			InUpOption.add(inquan);
			
			
			
			try {
				conn = DriverManager.getConnection(DBurl);
				String[][] SInv = FillInventory(conn);
				
				JTable inventorytable = new JTable(SInv, tHead);
				
				InUpOption.add(inventorytable);
				JOptionPane.showMessageDialog(null, InUpOption);
				
				updateInventory(conn, inid.getText(), initem.getText(), inquan.getText());
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchInventory(Connection conn) throws SQLException{
	 	
		ResultSet SearchTable;
		
		String sqlEmpInsert = "SELECT * FROM inventoryDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillInventory(Connection conn){
		String[][] inventoryList = null;
		try{
			ResultSet inventory = SearchInventory(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Integer> quantity = new ArrayList<Integer>();
			
			
			
			while (inventory.next()){
				
				ids.add(inventory.getInt("inventoryID"));
				names.add(inventory.getString("inventoryItem"));
				quantity.add(inventory.getInt("inventoryQuantity"));
				currentRow++;
				
			}
			inventoryList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				inventoryList[x][0] = String.valueOf(ids.get(x));
				inventoryList[x][1] = String.valueOf(names.get(x));
				inventoryList[x][2] = String.valueOf(quantity.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
	return inventoryList;
}
	public void updateInventory(Connection conn, String id, String Item, String Quant) throws SQLException{
		ResultSet SearchTable;
		
		String inId = String.valueOf(id);
		String inItem = Item;
		String inQu = Quant;
		
		
		String sqlEmpInsert = "SELECT * FROM inventoryDB WHERE inventoryID = ?";
		
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, id);
		
		SearchTable = prepStmt.executeQuery();
		
		while(SearchTable.next()){
			inId = String.valueOf(SearchTable.getInt("inventoryID"));
			if(inItem.equals("")){
				inItem = SearchTable.getString("inventoryItem");
			}
			if(inQu.equals("")){
				inQu = SearchTable.getString("inventoryQuantity");
			}
		}
		String sqlUpdate = "UPDATE inventoryDB SET inventoryItem = '" + inItem +
				"', inventoryQuantity = '" + inQu + "' WHERE inventoryID = " + inId;
		System.out.println(sqlUpdate);
		Statement ourUpdateStatement = conn.createStatement();
    	ourUpdateStatement.executeUpdate(sqlUpdate);
		
	}
	
	
	private class MenuListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel InUpOption = new JPanel();
			
			JTextField meid = new JTextField(5);
			JTextField meName = new JTextField(7);
			JTextField mePrice = new JTextField(5);
			JTextField meCat = new JTextField(7);
			
			String[] tHead = {"ID", "Name", "Price", "Catagory"};
			
			InUpOption.add(new JLabel("Menu ID: "));
			InUpOption.add(meid);
			InUpOption.add(new JLabel("Menu Name: "));
			InUpOption.add(meName);
			InUpOption.add(new JLabel("Menu Price: "));
			InUpOption.add(mePrice);
			InUpOption.add(new JLabel("Menu Catagory: "));
			InUpOption.add(meCat);
			
			
			
			try {
				conn = DriverManager.getConnection(DBurl);
				String[][] Sme = FillMenu(conn);
				
				JTable inventorytable = new JTable(Sme, tHead);
				
				InUpOption.add(inventorytable);
				JOptionPane.showMessageDialog(null, InUpOption);
				
				updateMenu(conn, meid.getText(), meName.getText(), mePrice.getText(), meCat.getText());
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchMenu(Connection conn) throws SQLException{
	 	
		ResultSet SearchTable;
		
		String sqlEmpInsert = "SELECT * FROM menuDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillMenu(Connection conn){
		String[][] menuList = null;
		try{
			ResultSet menu = SearchMenu(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> names = new ArrayList<String>();
			ArrayList<Double> price = new ArrayList<Double>();
			ArrayList<String> cata = new ArrayList<String>();
			
			
			while (menu.next()){
				ids.add(menu.getInt("menuID"));
				names.add(menu.getString("menuName"));
				price.add(menu.getDouble("menuPrice"));
				cata.add(menu.getString("menuCatagory"));
				currentRow++;
			}
			menuList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				menuList[x][0] = String.valueOf(ids.get(x));
				menuList[x][1] = String.valueOf(names.get(x));
				menuList[x][2] = String.valueOf(price.get(x));
				menuList[x][3] = String.valueOf(cata.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
			
		return menuList;
	}
	public void updateMenu(Connection conn, String id, String name, String Price, String Cata) throws SQLException{
		ResultSet SearchTable;
		
		String meId = String.valueOf(id);
		String meName = name;
		String mePrice = Price;
		String meCata = Cata;
		
		String sqlEmpInsert = "SELECT * FROM menuDB WHERE menuID = ?";
		
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, id);
		
		SearchTable = prepStmt.executeQuery();
		
		while(SearchTable.next()){
			meId = String.valueOf(SearchTable.getInt("menuID"));
			if(meName.equals("")){
				meName = SearchTable.getString("menuName");
			}
			if(mePrice.equals("")){
				mePrice = SearchTable.getString("menuPrice");
			}
			if(meCata.equals("")){
				meCata = SearchTable.getString("menuCatagory");
			}
		}
		String sqlUpdate = "UPDATE menuDB SET menuName = '" + meName +
				"', menuPrice = '" + mePrice +
				"', menuCatagory = '" + meCata + "' WHERE menuID = " + meId;
		System.out.println(sqlUpdate);
		Statement ourUpdateStatement = conn.createStatement();
    	ourUpdateStatement.executeUpdate(sqlUpdate);
		
	}
	
	private class OrdersListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel InUpOption = new JPanel();
			
			JTextField orid = new JTextField(5);
			JTextField ordid = new JTextField(5);
			JTextField ortable = new JTextField(5);
			JTextField ormenu = new JTextField(7);
			
			String[] tHead = {"ID", "Name", "Price", "Catagory"};
			
			InUpOption.add(new JLabel("Order ID: "));
			InUpOption.add(orid);
			InUpOption.add(new JLabel("Order Day ID: "));
			InUpOption.add(ordid);
			InUpOption.add(new JLabel("Order Table: "));
			InUpOption.add(ortable);
			InUpOption.add(new JLabel("Order Menu Item: "));
			InUpOption.add(ormenu);
			
			
			
			try {
				conn = DriverManager.getConnection(DBurl);
				String[][] Sord = FillOrders(conn);
				
				JTable inventorytable = new JTable(Sord, tHead);
				
				InUpOption.add(inventorytable);
				JOptionPane.showMessageDialog(null, InUpOption);
				
				updateOrders(conn, orid.getText(), ordid.getText(), ortable.getText(), ormenu.getText());
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchOrders(Connection conn) throws SQLException{

		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM OrdersDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillOrders(Connection conn){
		String[][] orderList = null;
		try{
			ResultSet order = SearchOrders(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> dayIds = new ArrayList<Integer>();
			ArrayList<Integer> table = new ArrayList<Integer>();
			ArrayList<Integer> menuitemid = new ArrayList<Integer>();
			
			while (order.next()){
				
				ids.add(order.getInt("orderID"));
				dayIds.add(order.getInt("orderDayID"));
				table.add(order.getInt("orderTable"));
				menuitemid.add(order.getInt("orderMenuItem"));
				currentRow++;
				
			}
			orderList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				orderList[x][0] = String.valueOf(ids.get(x));
				orderList[x][1] = String.valueOf(dayIds.get(x));
				orderList[x][2] = String.valueOf(table.get(x));
				orderList[x][3] = String.valueOf(menuitemid.get(x));
				
				
			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
			
		return orderList;
	}
	public void updateOrders(Connection conn, String id, String did, String table, String menuItem) throws SQLException{
		ResultSet SearchTable;
		
		String orId = String.valueOf(id);
		String ordid = did;
		String ortable = table;
		String ormenu = menuItem;
		
		String sqlEmpInsert = "SELECT * FROM OrdersDB WHERE orderID = ?";
		
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, id);
		
		SearchTable = prepStmt.executeQuery();
		
		while(SearchTable.next()){
			orId = String.valueOf(SearchTable.getInt("orderID"));
			if(ordid.equals("")){
				ordid = SearchTable.getString("orderDayID");
			}
			if(ortable.equals("")){
				ortable = SearchTable.getString("orderTable");
			}
			if(ormenu.equals("")){
				ormenu = SearchTable.getString("orderMenuItem");
			}
		}
		String sqlUpdate = "UPDATE OrdersDB SET orderDayID = " + ordid +
				", orderTable = '" + ortable +
				"', orderMenuItem = '" + ormenu + "' WHERE orderID = " + orId;
		System.out.println(sqlUpdate);
		Statement ourUpdateStatement = conn.createStatement();
    	ourUpdateStatement.executeUpdate(sqlUpdate);
	}
	
	
	private class TablesListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel InUpOption = new JPanel();
			
			JTextField tid = new JTextField(5);
			JTextField tnum = new JTextField(5);
			JTextField tseat = new JTextField(5);
			
			String[] tHead = {"ID", "Name", "Price"};
			
			InUpOption.add(new JLabel("Table ID: "));
			InUpOption.add(tid);
			InUpOption.add(new JLabel("Table Number: "));
			InUpOption.add(tnum);
			InUpOption.add(new JLabel("Table Seat #: "));
			InUpOption.add(tseat);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				String[][] Sord = FillTable(conn);
				
				JTable inventorytable = new JTable(Sord, tHead);
				
				InUpOption.add(inventorytable);
				JOptionPane.showMessageDialog(null, InUpOption);
				
				updateTables(conn, tid.getText(), tnum.getText(), tseat.getText());
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchTable(Connection conn) throws SQLException{

		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM tablesDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
	public String[][] FillTable(Connection conn){
		String[][] tableList = null;
		try{
			ResultSet table = SearchTable(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<Integer> num = new ArrayList<Integer>();
			ArrayList<Integer> seats = new ArrayList<Integer>();
			
			
			
			while (table.next()){
				ids.add(table.getInt("tableID"));
				num.add(table.getInt("tableNumber"));
				seats.add(table.getInt("tableSeats"));
				currentRow++;
				
			}
			tableList = new String[currentRow][4];
			
			for(int x = 0; x < currentRow; x++){
				
				tableList[x][0] = String.valueOf(ids.get(x));
				tableList[x][1] = String.valueOf(num.get(x));
				tableList[x][2] = String.valueOf(seats.get(x));

			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return tableList;
	}
	public void updateTables(Connection conn, String id, String num, String seats) throws SQLException{
		ResultSet SearchTable;
		
		String tabId = String.valueOf(id);
		String tabnum = num;
		String tabseat = seats;
		
		String sqlEmpInsert = "SELECT * FROM tablesDB WHERE tableID = ?";
		
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, id);
		
		SearchTable = prepStmt.executeQuery();
		
		while(SearchTable.next()){
			tabId = String.valueOf(SearchTable.getInt("tableID"));
			if(tabnum.equals("")){
				tabnum = SearchTable.getString("tableNumber");
			}
			if(tabseat.equals("")){
				tabseat = SearchTable.getString("tableSeats");
			}
		}
		String sqlUpdate = "UPDATE tablesDB SET tableNumber = " + tabnum +
				", tableSeats = '" + tabseat + "' WHERE tableID = " + tabId;
		System.out.println(sqlUpdate);
		Statement ourUpdateStatement = conn.createStatement();
    	ourUpdateStatement.executeUpdate(sqlUpdate);
	}
	
	
 	private class UsersListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://javaresturantDB.accdb";
			
			Connection conn;
			JPanel InUpOption = new JPanel();
			
			JTextField uid = new JTextField(5);
			JTextField uname = new JTextField(10);
			JTextField uphone = new JTextField(10);
			JTextField uposit = new JTextField(7);
			JTextField upass = new JTextField(15);
			JTextField uUname = new JTextField(15);
			
			
			String[] tHead = {"ID", "Name", "Price", "slot", "slot"
					, "slot"};
			
			InUpOption.add(new JLabel("User ID: "));
			InUpOption.add(uid);
			InUpOption.add(new JLabel("User Number: "));
			InUpOption.add(uname);
			InUpOption.add(new JLabel("User Phone #: "));
			InUpOption.add(uphone);
			InUpOption.add(new JLabel("User Position: "));
			InUpOption.add(uposit);
			InUpOption.add(new JLabel("User Password: "));
			InUpOption.add(upass);
			InUpOption.add(new JLabel("User Usernaem: "));
			InUpOption.add(uUname);
			
			try {
				conn = DriverManager.getConnection(DBurl);
				String[][] Sord = FillUsers(conn);
				
				JTable inventorytable = new JTable(Sord, tHead);
				
				InUpOption.add(inventorytable);
				JOptionPane.showMessageDialog(null, InUpOption);
				
				updateUsers(conn, uid.getText(), uname.getText(), uphone.getText(), uposit.getText(), upass.getText(), uUname.getText());
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
	}
 	public ResultSet SearchUsers(Connection conn) throws SQLException{
 		
		ResultSet SearchTable;
		String sqlEmpInsert = "SELECT * FROM usersDB";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		SearchTable = prepStmt.executeQuery();
		return SearchTable;
		
 	}
 	public String[][] FillUsers(Connection conn){
		String[][] usersList = null;
		try{
			ResultSet table = SearchUsers(conn);
			
			int currentRow = 0;
			ArrayList<Integer> ids = new ArrayList<Integer>();
			ArrayList<String> name = new ArrayList<String>();
			ArrayList<String> phone = new ArrayList<String>();
			ArrayList<String> position = new ArrayList<String>();
			ArrayList<String> pass = new ArrayList<String>();
			ArrayList<String> Uname = new ArrayList<String>();
			
			while (table.next()){
				ids.add(table.getInt("userID"));
				name.add(table.getString("userName"));
				phone.add(table.getString("userPhone"));
				position.add(table.getString("userPosition"));
				pass.add(table.getString("userPassword"));
				Uname.add(table.getString("userUname"));
				currentRow++;
				
			}
			usersList = new String[currentRow][6];
			
			for(int x = 0; x < currentRow; x++){
				
				usersList[x][0] = String.valueOf(ids.get(x));
				usersList[x][1] = String.valueOf(name.get(x));
				usersList[x][2] = String.valueOf(phone.get(x));
				usersList[x][3] = String.valueOf(position.get(x));
				usersList[x][4] = String.valueOf(pass.get(x));
				usersList[x][5] = String.valueOf(Uname.get(x));

			}	
			
			
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		
		return usersList;
	}
 	public void updateUsers(Connection conn, String id, String name, String phone, String posit, String pass, String username) throws SQLException{
 		ResultSet SearchTable;
		
		String usId = String.valueOf(id);
		String usname = name;
		String usphone = phone;
		String usposit = posit;
		String uspass = pass;
		String usuname = username;
		
		String sqlEmpInsert = "SELECT * FROM usersDB WHERE userID = ?";
		
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, id);
		
		SearchTable = prepStmt.executeQuery();
		
		while(SearchTable.next()){
			usId = String.valueOf(SearchTable.getInt("userID"));
			if(usname.equals("")){
				usname = SearchTable.getString("userName");
			}
			if(usphone.equals("")){
				usphone = SearchTable.getString("userPhone");
			}
			if(usposit.equals("")){
				usposit = SearchTable.getString("userPosition");
			}
			if(uspass.equals("")){
				uspass = SearchTable.getString("userPassword");
			}
			if(usuname.equals("")){
				usuname = SearchTable.getString("userUname");
			}
		}
		String sqlUpdate = "UPDATE usersDB SET userName = " + usname +
				"', userPhone = '" + usphone +
				"', userPosition = '" + usposit +
				"', userPassword = '" + uspass +
				"', userUname"
				+ " = '" + usuname +"' WHERE tableID = " + usId;
		System.out.println(sqlUpdate);
		Statement ourUpdateStatement = conn.createStatement();
    	ourUpdateStatement.executeUpdate(sqlUpdate);
 	}
 	
 	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		dbupdateController dbu = new dbupdateController();

	}

}
