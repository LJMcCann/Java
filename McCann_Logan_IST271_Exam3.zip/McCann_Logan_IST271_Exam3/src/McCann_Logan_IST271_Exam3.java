import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.ArrayList;
import java.util.Random;



public class McCann_Logan_IST271_Exam3 extends JFrame {
	
	public JFrame MenuFrame;
	public JFrame CardsFrame;
	public JFrame DiceFrame;
	
	
	
	public JMenuBar menuBar;
	public JMenu Menu;
	public JMenuItem Cards;
	public JMenuItem Dice;
	
	
	public JPanel PanelDice, PanelCards;
	public JLabel labelDice, labelCards;
	
	
	public McCann_Logan_IST271_Exam3(){
		setSize(200, 200);
		buildMenuBar();
	
		
		
		
		
		
		setVisible(true);
		
	}
	public void buildMenuBar(){
		
		menuBar = new JMenuBar();
		Menu = new JMenu("Game");
		Cards = new JMenuItem("Cards");
		Dice = new JMenuItem("Dice");
		
		
		Cards.addActionListener(new MenuListener());
		Dice.addActionListener(new MenuListener());
		
		Menu.add(Cards);
		Menu.add(Dice);
		
		menuBar.add(Menu);
		
		setJMenuBar(menuBar);
		
		
	}
	
	private class MenuListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			String ActionGame = e.getActionCommand();
			
			
			if (ActionGame.equals("Dice")){
				rollDice rd = new rollDice();
				rd.setVisible(true);
			}else if (ActionGame.equals("Cards")){
				thirtyOne to = new thirtyOne();
				to.setVisible(true);
			}
		}
		
	}
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		McCann_Logan_IST271_Exam3 gui = new McCann_Logan_IST271_Exam3();
		
		
		
	}

}
