import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.ArrayList;
import java.util.Random;


public class rollDice extends JFrame {
	
	private JPanel die1Panel;        // A panel to hold a label
	private JPanel die2Panel;        // A panel to hold a label
	private JPanel buttonPanel;      // A panel to hold a button
	private JLabel die1Label;        // A label to hold an image
	private JLabel die2Label, die3Label, die4Label, die5Label, die6Label, die7Label, die8Label, die9Label, die10Label, die11Label, die12Label;        // A label to hold an image
	private ImageIcon die1Image;     // To hold an image of die1
	private ImageIcon die2Image, die3Image, die4Image, die5Image, die6Image, die7Image, die8Image, die9Image, die10Image, die11Image, die12Image;     // To hold an image of die2
	private JButton button;          // A button to get roll the dice
	private Container contentPane;   // To reference the content pane
	   
	private ArrayList<ImageIcon> dieImageList;  // To hold the die images.
	
	private JPanel resultsPanel;
	private JLabel p1Label, p2Label;
	
	private JTextField p1Score, p2Score;
	
	int Score1 = 0, Score2 = 0;

	
	public rollDice(){


	      // Set the title.
	      setTitle("Dice Game");
	   
	      // Set the size of the window.
	      setSize(1500, 400);

	      // Specify what happens when the close button is clicked.
	      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	      
	      // Create a BorderLayout manager for the content pane.
	      setLayout(new BorderLayout());
	       
	      // Build the dieImageList
	      buildDieImageList();

	      // Build the panels.
	      buildDie1Panel();
	      buildDie2Panel();
	      buildButtonPanel();
	      buildResultsPanel();

	      // Add the panels to the content pane.
	      add(die1Panel, BorderLayout.WEST);
	      add(die2Panel, BorderLayout.EAST);
	      add(buttonPanel, BorderLayout.NORTH);
	      add(resultsPanel, BorderLayout.SOUTH);
	      
	      // Roll the dice initially.
	      rollTheDice();
	      
	      // Display the window.
	      setVisible(true);
		
		
	}
	
	
	private void buildDie1Panel()
   {
		// Create a panel.
		die1Panel = new JPanel();

	      // Create a label.
	    die1Label = new JLabel();
	    die2Label = new JLabel();
	    die3Label = new JLabel();
	    die4Label = new JLabel();
	    die5Label = new JLabel();
	    die6Label = new JLabel();

	      // Add the label to the panel.
	    die1Panel.add(die1Label);
	    die1Panel.add(die2Label);
	    die1Panel.add(die3Label);
	    die1Panel.add(die4Label);
	    die1Panel.add(die5Label);
	    die1Panel.add(die6Label);
	   }
	
	private void buildDie2Panel()
	   {
	      // Create a panel.
	      die2Panel = new JPanel();

	      // Create a label.
		    die7Label = new JLabel();
		    die8Label = new JLabel();
		    die9Label = new JLabel();
		    die10Label = new JLabel();
		    die11Label = new JLabel();
		    die12Label = new JLabel();

		      // Add the label to the panel.
		    die2Panel.add(die7Label);
		    die2Panel.add(die8Label);
		    die2Panel.add(die9Label);
		    die2Panel.add(die10Label);
		    die2Panel.add(die11Label);
		    die2Panel.add(die12Label);
	   }

	private void buildResultsPanel(){
		resultsPanel = new JPanel();
		
		p1Label = new JLabel("Player1 Score:");
		p2Label = new JLabel("Player2 Score:");
		
		p1Score = new JTextField();
		p2Score = new JTextField();
		
		
		resultsPanel.add(p1Label);
		resultsPanel.add(p1Score);
		resultsPanel.add(p2Label);
		resultsPanel.add(p2Score);
	}
	
	private void rollTheDice()
	   {
	      // Create a reference to a Random object.
	      Random rand = new Random();      

	      // Generate a random number between 0 and the 
	      // number of items in the array list, and store 
	      // the value in the index variables.
	      int index1 = rand.nextInt(dieImageList.size());
	      int index2 = rand.nextInt(dieImageList.size());
	      int index3 = rand.nextInt(dieImageList.size());
	      int index4 = rand.nextInt(dieImageList.size());
	      int index5 = rand.nextInt(dieImageList.size());
	      int index6 = rand.nextInt(dieImageList.size());
	      int index7 = rand.nextInt(dieImageList.size());
	      int index8 = rand.nextInt(dieImageList.size());
	      int index9 = rand.nextInt(dieImageList.size());
	      int index10 = rand.nextInt(dieImageList.size());
	      int index11 = rand.nextInt(dieImageList.size());
	      int index12 = rand.nextInt(dieImageList.size());

	      // Get images from the array list using
	      // the index values that were generated.
	      die1Image = dieImageList.get(index1);
	      Score1=index1+1;
	      die2Image = dieImageList.get(index2);
	      Score1=index2+1;
	      die3Image = dieImageList.get(index3);
	      Score1=index3+1;
	      die4Image = dieImageList.get(index4);
	      Score1=index4+1;
	      die5Image = dieImageList.get(index5);
	      Score1=index5+1;
	      die6Image = dieImageList.get(index6);
	      Score1=index6+1;
	      die7Image = dieImageList.get(index7);
	      die8Image = dieImageList.get(index8);
	      die9Image = dieImageList.get(index9);
	      die10Image = dieImageList.get(index10);
	      die11Image = dieImageList.get(index11);
	      die12Image = dieImageList.get(index12);
	      
	      
	      // Display the dice.
	      die1Label.setIcon(die1Image); 
	      die2Label.setIcon(die2Image);
	      die3Label.setIcon(die3Image);
	      die4Label.setIcon(die4Image);
	      die5Label.setIcon(die5Image);
	      die6Label.setIcon(die6Image);
	      die7Label.setIcon(die7Image);
	      die8Label.setIcon(die8Image);
	      die9Label.setIcon(die9Image);
	      die10Label.setIcon(die10Image);
	      die11Label.setIcon(die11Image);
	      die12Label.setIcon(die12Image);
	   }
	
	private void countPoints(){
		
		//player1 = Score1
	
		//p1Score.setText(t);
		
	}

	private void buildDieImageList()
	   {
	      // Create the dieImageList ArrayList 
	      // to hold the ImageIcon objects.
	      dieImageList = new ArrayList<>();
	      
	      // Add the ImageIcon objects to the 
	      // dieImageList ArrayList
	      dieImageList.add(new ImageIcon("Dice\\d12_1.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_2.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_3.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_4.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_5.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_6.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_7.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_8.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_9.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_10.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_11.jpg"));
	      dieImageList.add(new ImageIcon("Dice\\d12_12.jpg"));
	      
	   }



	private void buildButtonPanel()
	   {
	      // Create a panel.
	      buttonPanel = new JPanel();
	   
	      // Create a button.
	      button = new JButton("Roll the Dice");
	      button.setMnemonic(KeyEvent.VK_R);
	      button.setToolTipText("Click here to roll the dice.");
	      
	      // Register an action listener with the button.
	      button.addActionListener(new ButtonListener());
	      
	      // Add the button to the panel.
	      buttonPanel.add(button);
	   }

	private class ButtonListener implements ActionListener
	   {
	      public void actionPerformed(ActionEvent e)
	      {
	         // Roll the dice.
	         rollTheDice();
	         countPoints();
	      }
	   }


}






