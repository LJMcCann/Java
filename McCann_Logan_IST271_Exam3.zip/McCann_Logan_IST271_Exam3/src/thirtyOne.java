import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.ArrayList;
import java.util.Random;

public class thirtyOne extends JFrame {
	
	private JPanel deckPanel;		
	private JPanel MainCardPanel;        
	private JPanel cardPanel1, cardPanel2;
	private JPanel buttonPanel;
	private JButton DealButton, DealNextButton, standButton;
	private JLabel deckLabel, winnerLabel, score1Label, score2Label;        
	private JLabel cardLabel1, cardLabel2, cardLabel3
	, cardLabel4, cardLabel5, cardLabel6, cardLabel7, cardLabel8, cardLabel9, cardLabel10;
	private ArrayList<ImageIcon> cardImageList;
	private ImageIcon deckImage;     // To hold a deck image
	   private ImageIcon cardImage1, cardImage2, cardImage3, cardImage4, cardImage5, cardImage6, cardImage7, cardImage8, cardImage9, cardImage10;
	   int cards = 3;
	   
	   int Score1 = 0, Score2 = 0;
	   
	   public thirtyOne(){
			
			setTitle("Thirty One");
			
			setSize(1700,800);
			
			setLayout(new BorderLayout());
			buildCardImageList();
			buildDeckPanel();
			buildCardPanel1();
			buildCardPanel2();
			buildButtonPanel();
		
			
			
			add(deckPanel, BorderLayout.WEST);
			add(cardPanel1, BorderLayout.NORTH);
			add(cardPanel2, BorderLayout.SOUTH);
			add(buttonPanel, BorderLayout.EAST);
			
			
			setVisible(true);
			
			
		}
		
		private void buildDeckPanel()
		   {
		      // Create a panel.
		      deckPanel = new JPanel();

		      // Create an image icon to represent the deck of cards.
		      deckImage = new ImageIcon("Cards\\Backface_Blue.jpg");

		      // Create a label using the image for the deck of cards.
		      deckLabel = new JLabel(deckImage);

		      // Add the label to the panel.
		      deckPanel.add(deckLabel);
		   
		   }
		
		private void buildCardPanel1()
		   {
		      // Create a panel.
		      cardPanel1 = new JPanel();

		      // Create a label.
		      cardLabel1 = new JLabel();
		      cardLabel2 = new JLabel();
		      cardLabel3 = new JLabel();
		      cardLabel7 = new JLabel();
		      cardLabel8 = new JLabel();

		      // Add the label to the panel.
		      cardPanel1.add(cardLabel1);
		      cardPanel1.add(cardLabel2);
		      cardPanel1.add(cardLabel3);
		      cardPanel1.add(cardLabel7);
		      cardPanel1.add(cardLabel8);
		   }
		private void buildCardPanel2()
		   {
		      // Create a panel.
		      cardPanel2 = new JPanel();

		      // Create a label.
		      cardLabel4 = new JLabel();
		      cardLabel5 = new JLabel();
		      cardLabel6 = new JLabel();
		      cardLabel9 = new JLabel();
		      cardLabel10 = new JLabel();

		      // Add the label to the panel.
		      cardPanel2.add(cardLabel4);
		      cardPanel2.add(cardLabel5);
		      cardPanel2.add(cardLabel6);
		      cardPanel2.add(cardLabel9);
		      cardPanel2.add(cardLabel10);
		   }
		
		
		
		private void buildButtonPanel(){
			buttonPanel = new JPanel();
			
			   
		      // Create a button.
		      JButton DealButton = new JButton("Deal Hands");
		      JButton DealNewButton = new JButton("Deal Next");
		      JButton StandButton = new JButton("Stand");
		      DealButton.setToolTipText("Click here to deal a card.");
		      
		      DealButton.addActionListener(new ButtonDealListener());
		      DealNewButton.addActionListener(new ButtonNewListener());
		      //StandButton.addActionListener(new ButtonStandListener());
		      
		      
		      buttonPanel.add(DealButton);
		      buttonPanel.add(DealNewButton);
		      buttonPanel.add(StandButton);

		}
		
		private void calcPoints(int cardLabel, int player){
			
			int placeHolder;
			
			//not my proudest fix
			if ( 0 <=cardLabel|| cardLabel<= 3 ){
				placeHolder=2;
			}
			if ( 4 <=cardLabel|| cardLabel<= 7 ){
				placeHolder=3;
			}
			if ( 8 <=cardLabel|| cardLabel<= 11 ){
				placeHolder=4;
			}
			if ( 12 <=cardLabel|| cardLabel<= 15 ){
				placeHolder=5;
			}
			if ( 16 <=cardLabel|| cardLabel<= 19 ){
				placeHolder=6;
			}
			if ( 20 <=cardLabel|| cardLabel<= 23 ){
				placeHolder=7;
			}
			if ( 24 <=cardLabel|| cardLabel<= 27 ){
				placeHolder=8;
			}
			if ( 28 <=cardLabel|| cardLabel<= 31 ){
				placeHolder=9;
			}
			if ( 48 <=cardLabel|| cardLabel<= 51 ){
				placeHolder=11;
			}
			else{
				placeHolder=10;
			}
			
			if (player == 1){
				Score1+= placeHolder;
				
			}
			else{
				Score2+= placeHolder;
				
			}
			
			
		}	
			
		private void winner(){	
			if (Score1 >= 31){
				JOptionPane.showMessageDialog(null, "Player2 Wins!");
			}
			else if (Score2 >= 31){
				JOptionPane.showMessageDialog(null, "Player1 Wins!");
			}
			else if (Score1 > Score2 && cards >=5){
				JOptionPane.showMessageDialog(null, "Player1 Wins!");
			}
			else if (Score1 < Score2 && cards >=5){
				JOptionPane.showMessageDialog(null, "Player2 Wins!");
			}
		}
		
		private class ButtonDealListener implements ActionListener {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				if(cardImageList.size() == 52){
				
				Random rand = new Random();
				   
	            int index = rand.nextInt(cardImageList.size());
	            int index2 = rand.nextInt(cardImageList.size());
	            int index3 = rand.nextInt(cardImageList.size());
	            int index4 = rand.nextInt(cardImageList.size());
	            int index5 = rand.nextInt(cardImageList.size());
	            int index6 = rand.nextInt(cardImageList.size());
				
	            cardImage1 = cardImageList.get(index);
	            cardImage2 = cardImageList.get(index2);
	            cardImage3 = cardImageList.get(index3);
	            cardImage4 = cardImageList.get(index4);
	            cardImage5 = cardImageList.get(index5);
	            cardImage6 = cardImageList.get(index6);
	                        
	            cardLabel1.setIcon(cardImage1);
	           cardImageList.remove(index);
	           calcPoints(index, 1);
	            
	            cardLabel2.setIcon(cardImage2);
	            cardImageList.remove(index2);
	            //calcPoints(index2, 1);
	            
	            cardLabel3.setIcon(cardImage3);
	            cardImageList.remove(index3);
	            //calcPoints(index3, 1);
	            
	            cardLabel4.setIcon(cardImage4);
	            cardImageList.remove(index4);
	            calcPoints(index4, 2);
	            
	            cardLabel5.setIcon(cardImage5);
	            cardImageList.remove(index5);
	            //calcPoints(index5, 2);
	            
	            cardLabel6.setIcon(cardImage6);
	            cardImageList.remove(index6);
	            //calcPoints(index6, 2);
	            
	            
	            //winner();
	            
				}
				
			}
			
			
			
		}
		
		
		private class ButtonNewListener implements ActionListener {
			
			

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				Random rand = new Random();
				
		
			if(cards == 3){
				int index7 = rand.nextInt(cardImageList.size());
				int index9 = rand.nextInt(cardImageList.size());
			
				cardImage7 = cardImageList.get(index7);
				cardImage9 = cardImageList.get(index9);
				
				cardLabel7.setIcon(cardImage7);
	            cardImageList.remove(index7);
	            cardLabel9.setIcon(cardImage9);
	            cardImageList.remove(index9);
	            
	           
			
			}else if(cards == 4){
				int index8 = rand.nextInt(cardImageList.size());
				int index10 = rand.nextInt(cardImageList.size());
			
				cardImage8 = cardImageList.get(index8);
				cardImage10 = cardImageList.get(index10);
				
				cardLabel8.setIcon(cardImage8);
	            cardImageList.remove(index8);
	            cardLabel10.setIcon(cardImage10);
	            cardImageList.remove(index10);
	            
	            
			}
			cards+=1;
			
			}
			
            
		}
		
		
		//private class ButtonStandListener implements ActionListener{
			
			
			
		//}
		
		
		
		
		private void buildCardImageList()
		   {
		      // Create the cardImageList ArrayList 
		      // to hold the ImageIcon objects.
		      cardImageList = new ArrayList<>();
		      
		      // Add the ImageIcon objects to the cardImageList ArrayList
		      cardImageList.add(new ImageIcon("Cards\\2_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\2_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\2_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\2_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\3_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\3_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\3_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\3_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\4_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\4_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\4_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\4_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\5_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\5_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\5_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\5_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\6_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\6_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\6_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\6_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\7_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\7_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\7_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\7_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\8_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\8_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\8_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\8_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\9_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\9_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\9_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\9_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\10_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\10_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\10_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\10_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\Jack_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Jack_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Jack_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Jack_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\Queen_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Queen_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Queen_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Queen_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\King_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\King_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\King_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\King_Spades.jpg"));
		      
		      cardImageList.add(new ImageIcon("Cards\\Ace_Clubs.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Ace_Diamonds.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Ace_Hearts.jpg"));
		      cardImageList.add(new ImageIcon("Cards\\Ace_Spades.jpg"));
		                                                  
		   }






}
		
		
		
		
