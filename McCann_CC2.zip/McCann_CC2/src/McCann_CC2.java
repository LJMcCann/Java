import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class McCann_CC2 extends JFrame{
	
	public JPanel searchPan;
	public JPanel insertPan;
	public JPanel updatePan;
	public JPanel deletePan;
	public JPanel tablesPan;
	
	public JTable Displaytable;
	
	
	public JButton searchemp;
	public JButton searchpat;
	public JButton searchloc;
	public JButton searchapp;
	
	public JButton insertemp;
	public JButton insertpat;
	public JButton insertloc;
	public JButton insertapp;
	
	public JButton updateemp;
	public JButton updatepat;
	public JButton updateloc;
	public JButton updateapp;
	
	public JButton deleteemp;
	public JButton deletepat;
	public JButton deleteloc;
	public JButton deleteapp;
	
	
	
	
	public McCann_CC2() {
		
		setTitle("Hospital Database");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(800, 200);
		buildSearch();
		buildInsert();
		buildUpdate();
		buildDelete();
		
		setLayout(new GridLayout(1,4));
		
		add(searchPan);
		add(insertPan);
		add(updatePan);
		add(deletePan);
		
		
		setVisible(true);

	}

	public void buildSearch(){
		searchPan = new JPanel();
		
		searchemp = new JButton("Search Employees");
		searchpat = new JButton("Search Patients");
		searchloc = new JButton("Search Locations");
		searchapp = new JButton("Search Appointments");
		
		searchemp.addActionListener(new SearchEmpListener());
		searchpat.addActionListener(new SearchPatListener());
		searchloc.addActionListener(new SearchLocListener());
		searchapp.addActionListener(new SearchAppListener());
		
		
		searchPan.add(searchemp);
		searchPan.add(searchpat);
		searchPan.add(searchloc);
		searchPan.add(searchapp);
		
	}
	private class SearchEmpListener implements ActionListener {

		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			ResultSet searchInfo = null;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				searchInfo = SearchEmployee(conn);
				
				Displaytable = new JTable();
				Displaytable.setModel(DbUtils.resultSetToTableModel(searchInfo));
				
				
				JOptionPane.showMessageDialog(null, Displaytable);;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	private class SearchPatListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			ResultSet searchInfo = null;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				searchInfo = SearchPatient(conn);
				
				Displaytable = new JTable();
				Displaytable.setModel(DbUtils.resultSetToTableModel(searchInfo));
				
				
				JOptionPane.showMessageDialog(null, Displaytable);;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	private class SearchLocListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			ResultSet searchInfo = null;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				searchInfo = SearchLocation(conn);
				
				Displaytable = new JTable();
				Displaytable.setModel(DbUtils.resultSetToTableModel(searchInfo));
				
				
				JOptionPane.showMessageDialog(null, Displaytable);;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	private class SearchAppListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			ResultSet searchInfo = null;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				searchInfo = SearchAppointment(conn);
				
				Displaytable = new JTable();
				Displaytable.setModel(DbUtils.resultSetToTableModel(searchInfo));
				
				
				JOptionPane.showMessageDialog(null, Displaytable);;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	public ResultSet SearchEmployee(Connection conn) throws SQLException{
		
		String empid;
		String empname;
		String empadd;
		String empphone;
		String emppos;
		
		empid = JOptionPane.showInputDialog("Input Employee ID or hit ENTER: ");
		empname = JOptionPane.showInputDialog("Input Employee Name or hit ENTER: ");
		empadd = JOptionPane.showInputDialog("Input Employee Address or hit OK: ");
		empphone = JOptionPane.showInputDialog("Input Employee Phone or hit OK: ");
		emppos = JOptionPane.showInputDialog("Input Employee Position or hit OK: ");
		
		
		String sqlEmpSelect = "SELECT * FROM employeedb where " 
							+ "employeeid like ? AND "
							+ "employeename Like ? AND "
							+ "employeeaddress Like ? AND "
							+ "employeephone Like ? AND "
							+ "employeeposition Like ?";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpSelect);
		
		prepStmt.setString(1,  "%" + empid + "%");
		prepStmt.setString(2,  "%" + empname + "%");
		prepStmt.setString(3,  "%" + empadd + "%");
		prepStmt.setString(4,  "%" + empphone + "%");
		prepStmt.setString(5,  "%" + emppos + "%");
		
		ResultSet userResults = prepStmt.executeQuery();
		
		return userResults;
		
		
	}
	public ResultSet SearchPatient(Connection conn) throws SQLException{
		
		String patid;
		String patname;
		String patphone;
		
		patid = JOptionPane.showInputDialog("Input Patient ID or hit OK: ");
		patname = JOptionPane.showInputDialog("Input Patient Name or hit OK: ");
		patphone = JOptionPane.showInputDialog("Input Patient Phone Number or hit OK: ");
		
		String sqlPatSelect = "Select * FROM patientdb where "
							+ "patientid like ? AND "
							+ "patientname like ? AND "
							+ "patientphone like ?";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlPatSelect);
		
		prepStmt.setString(1, "%" + patid + "%");
		prepStmt.setString(2, "%" + patname + "%");
		prepStmt.setString(3, "%" + patphone + "%");
		
		ResultSet userResults = prepStmt.executeQuery();
		
		return userResults;
	}
	public ResultSet SearchLocation(Connection conn) throws SQLException{
		String locid;
		String locname;
		
		
		locid = JOptionPane.showInputDialog("Input Location ID or hit OK: ");
		locname = JOptionPane.showInputDialog("Input Location Name or hit OK: ");
		
		String sqllocSelect = "Select * FROM locationdb where "
							+ "locationid like ? AND "
							+ "locationname like ?";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqllocSelect);
		
		prepStmt.setString(1, "%" + locid + "%");
		prepStmt.setString(2, "%" + locname + "%");
		
		ResultSet userResults = prepStmt.executeQuery();
		
		return userResults;
	}
	public ResultSet SearchAppointment(Connection conn) throws SQLException{
		
		String appid;
		String apppat;
		String apploc;
		String appemp;
		String appTime;
		
		appid = JOptionPane.showInputDialog("Input Appointment ID or hit ENTER: ");
		apppat = JOptionPane.showInputDialog("Input Appointment Patient or hit ENTER: ");
		apploc = JOptionPane.showInputDialog("Input Appointment Location or hit OK: ");
		appemp = JOptionPane.showInputDialog("Input Appointment Employee or hit OK: ");
		appTime = JOptionPane.showInputDialog("Input Appointment Time or hit OK: ");
		
		
		String sqlEmpSelect = "SELECT * FROM appointmentdb where " 
							+ "appointmentid like ? AND "
							+ "patient Like ? AND "
							+ "location Like ? AND "
							+ "employee Like ? AND "
							+ "appointmenttime Like ?";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpSelect);
		
		prepStmt.setString(1,  "%" + appid + "%");
		prepStmt.setString(2,  "%" + apppat + "%");
		prepStmt.setString(3,  "%" + apploc + "%");
		prepStmt.setString(4,  "%" + appemp + "%");
		prepStmt.setString(5,  "%" + appTime + "%");
		
		ResultSet userResults = prepStmt.executeQuery();
		
		return userResults;
	}

 	public void buildInsert(){
		insertPan = new JPanel();
		
		insertemp = new JButton("Insert Employee");
		insertpat = new JButton("Insert Patient");
		insertloc = new JButton("Insert Location");
		insertapp = new JButton("Insert Appointment");
		
		insertemp.addActionListener(new InsertEmpListener());
		insertpat.addActionListener(new InsertPatListener());
		insertloc.addActionListener(new InsertLocListener());
		insertapp.addActionListener(new InsertAppListener());
		
		insertPan.add(insertemp);
		insertPan.add(insertpat);
		insertPan.add(insertloc);
		insertPan.add(insertapp);
	}	
 	private class InsertEmpListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				InsertEmployee(conn);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
 		
 	}
 	private class InsertPatListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				InsertPatient(conn);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
 		
 	}
 	private class InsertLocListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				InsertLocation(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
 		
 	}
 	private class InsertAppListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				InsertAppointment(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
 		
 	}
 	public void InsertEmployee(Connection conn) throws SQLException{
 		
 		String empid;
		String empname;
		String empadd;
		String empphone;
		String emppos;
		
		empid = JOptionPane.showInputDialog("Input Employee ID: ");
		empname = JOptionPane.showInputDialog("Input Employee Name: ");
		empadd = JOptionPane.showInputDialog("Input Employee Email: ");
		empphone = JOptionPane.showInputDialog("Input Employee Phone: ");
		emppos = JOptionPane.showInputDialog("Input Employee Position: ");
		
		String sqlEmpInsert = "INSERT INTO employeedb (employeeid, employeename, employeeaddress, employeephone, employeeposition) "
							+ "VALUES (?, ?, ?, ?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpInsert);
		
		prepStmt.setString(1, empid);
		prepStmt.setString(2, empname);
		prepStmt.setString(3, empadd);
		prepStmt.setString(4, empphone);
		prepStmt.setString(5, emppos);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}
 	public void InsertPatient(Connection conn) throws SQLException{
 		String patid;
		String patname;
		String patphone;
		
		patid = JOptionPane.showInputDialog("Input Patient ID: ");
		patname = JOptionPane.showInputDialog("Input Patient Name: ");
		patphone = JOptionPane.showInputDialog("Input Patient Phone Number: ");
		
		String sqlPatInsert = "INSERT INTO patientdb (patientid, patientname, patientphone) "
				+ "VALUES (?, ?, ?)";

		PreparedStatement prepStmt = conn.prepareStatement(sqlPatInsert);

		prepStmt.setString(1, patid);
		prepStmt.setString(2, patname);
		prepStmt.setString(3, patphone);

		prepStmt.executeUpdate();
		prepStmt.close();
 	}
 	public void InsertLocation(Connection conn) throws SQLException{
 		String locid;
		String locname;
		
		locid = JOptionPane.showInputDialog("Input Location ID: ");
		locname = JOptionPane.showInputDialog("Input Location Name: ");
		
		String sqlLocInsert = "INSERT INTO locationdb (locationid, locationname) "
				+ "VALUES (?, ?)";

		PreparedStatement prepStmt = conn.prepareStatement(sqlLocInsert);

		prepStmt.setString(1, locid);
		prepStmt.setString(2, locname);

		prepStmt.executeUpdate();
		prepStmt.close();
 	}
 	public void InsertAppointment(Connection conn) throws SQLException{
 		String appid;
		String apppat;
		String apploc;
		String appemp;
		String appTime;
		
		appid = JOptionPane.showInputDialog("Input Appointment ID: ");
		apppat = JOptionPane.showInputDialog("Input Appointment Patient: ");
		apploc = JOptionPane.showInputDialog("Input Appointment Location: ");
		appemp = JOptionPane.showInputDialog("Input Appointment Employee: ");
		appTime = JOptionPane.showInputDialog("Input Appointment Time: ");
		
		String sqlAppInsert = "INSERT INTO appointmentdb (appointmentid, patient, location, employee, appointmenttime) "
							+ "VALUES (?, ?, ?, ?, ?)";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlAppInsert);
		
		prepStmt.setString(1, appid);
		prepStmt.setString(2, apppat);
		prepStmt.setString(3, apploc);
		prepStmt.setString(4, appemp);
		prepStmt.setString(5, appTime);
		
		prepStmt.executeUpdate();
		prepStmt.close();
		
 	}
 	
 	public void buildUpdate(){
		updatePan = new JPanel();
		
		updateemp = new JButton("Update Employee");
		updatepat = new JButton("Update Patient");
		updateloc = new JButton("Update Location");
		updateapp = new JButton("Update Appointment");
		
		updateemp.addActionListener(new UpdateEmpListener());
		updatepat.addActionListener(new UpdatePatListener());
		updateloc.addActionListener(new UpdateLocListener());
		updateapp.addActionListener(new UpdateAppListener());
		
		updatePan.add(updateemp);
		updatePan.add(updatepat);
		updatePan.add(updateloc);
		updatePan.add(updateapp);
	}
 	private class UpdateEmpListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				UpdateEmployee(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
 		
 	}
 	private class UpdatePatListener implements ActionListener {
 		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				UpdatePatient(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
 	}
 	private class UpdateLocListener implements ActionListener {
 		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				UpdateLocation(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
 	}
 	private class UpdateAppListener implements ActionListener {
 		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				UpdateAppointment(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
 	}
 	public void UpdateEmployee(Connection conn) throws SQLException{
 		String empid;
		String empname;
		String empadd;
		String empphone;
		String emppos;
		
		empid = JOptionPane.showInputDialog("Input Employee ID to be changed: ");
		empname = JOptionPane.showInputDialog("Input new Employee Name: ");
		empadd = JOptionPane.showInputDialog("Input new Employee Email: ");
		empphone = JOptionPane.showInputDialog("Input new Employee Phone: ");
		emppos = JOptionPane.showInputDialog("Input new Employee Position: ");
		
		String sqlEmpUpdate = "UPDATE employeedb set employeename = ?, "
				+ "employeeaddress = ?, employeephone = ?, employeeposition = ? WHERE employeeid = ?";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpUpdate);
		
		prepStmt.setString(1, empname);
		prepStmt.setString(2, empadd);
		prepStmt.setString(3, empphone);
		prepStmt.setString(4, emppos);
		prepStmt.setString(5, empid);
		
		prepStmt.executeUpdate();
		prepStmt.close();
 	}
 	public void UpdatePatient(Connection conn) throws SQLException{
 		String patid;
		String patname;
		String patphone;
		
		patid = JOptionPane.showInputDialog("Input Patient ID: ");
		patname = JOptionPane.showInputDialog("Input Patient Name: ");
		patphone = JOptionPane.showInputDialog("Input Patient Phone Number: ");
		
		String sqlPatUpdate = "UPDATE patientdb set patientname = ?, "
				+ "patientphone = ? WHERE patientid = ?";

		PreparedStatement prepStmt = conn.prepareStatement(sqlPatUpdate);

		prepStmt.setString(1, patname);
		prepStmt.setString(2, patphone);
		prepStmt.setString(3, patid);
		
		prepStmt.executeUpdate();
		prepStmt.close();

 	}
 	public void UpdateLocation(Connection conn) throws SQLException{
 		String locid;
		String locname;
		
		locid = JOptionPane.showInputDialog("Input Location ID: ");
		locname = JOptionPane.showInputDialog("Input Location Name: ");
		
		String sqlLocUpdate = "UPDATE locationdb set locationname = ? Where locationid = ?";

		PreparedStatement prepStmt = conn.prepareStatement(sqlLocUpdate);

		prepStmt.setString(1, locname);
		prepStmt.setString(2, locid);

		prepStmt.executeUpdate();
		prepStmt.close();
 	}
 	public void UpdateAppointment(Connection conn) throws SQLException{
 		String appid;
		String apppat;
		String apploc;
		String appemp;
		String appTime;
		
		appid = JOptionPane.showInputDialog("Input Appointment ID: ");
		apppat = JOptionPane.showInputDialog("Input Appointment Patient: ");
		apploc = JOptionPane.showInputDialog("Input Appointment Location: ");
		appemp = JOptionPane.showInputDialog("Input Appointment Employee: ");
		appTime = JOptionPane.showInputDialog("Input Appointment Time: ");
		
		String sqlAppInsert = "UPDATE appointmentdb set patient = ?, location = ?, "
							+ "employee = ?, appointmenttime = ? WHERE appointmentid = ?";
		
		PreparedStatement prepStmt = conn.prepareStatement(sqlAppInsert);
		
		prepStmt.setString(1, apppat);
		prepStmt.setString(2, apploc);
		prepStmt.setString(3, appemp);
		prepStmt.setString(4, appTime);
		prepStmt.setString(5, appid);
		
		prepStmt.executeUpdate();
		prepStmt.close();
 	}
 	
  	public void buildDelete(){
		deletePan = new JPanel();
		
		deleteemp = new JButton("Delete Employee");
		deletepat = new JButton("Delete Patient");
		deleteloc = new JButton("Delete Location");
		deleteapp = new JButton("Delete Appointment");
		
		deleteemp.addActionListener(new DeleteEmpListener());
		deletepat.addActionListener(new DeletePatListener());
		deleteloc.addActionListener(new DeleteLocListener());
		deleteapp.addActionListener(new DeleteAppListener());
		
		deletePan.add(deleteemp);
		deletePan.add(deletepat);
		deletePan.add(deleteloc);
		deletePan.add(deleteapp);
	}
  	private class DeleteEmpListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				DeleteEmployee(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
  	}
  	private class DeletePatListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				DeletePatient(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
  	}
  	private class DeleteLocListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				DeleteLocation(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
  	}
  	private class DeleteAppListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			final String DBurl = "jdbc:ucanaccess://DoctorsofficeDB.accdb";
			
			Connection conn;
			
			try {
				conn = DriverManager.getConnection(DBurl);
				
				DeleteAppointment(conn);
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
  	}
  	public void DeleteEmployee(Connection conn) throws SQLException{
  		
  		String empid;
  		
  		empid = JOptionPane.showInputDialog("Input Employee ID to be Deleted: ");
  		
  		String sqlEmpDelete = "DELETE * FROM employeedb WHERE employeeid = ?";
  		
  		PreparedStatement prepStmt = conn.prepareStatement(sqlEmpDelete);
  		
  		prepStmt.setString(1, empid);
  		
  		prepStmt.executeUpdate();
		prepStmt.close();
  		
  	}
  	public void DeletePatient(Connection conn) throws SQLException{
  		String patid;
  		
  		patid = JOptionPane.showInputDialog("Input Patient ID to be Deleted: ");
  		
  		String sqlPatDelete = "DELETE * FROM patientdb WHERE patientid = ?";
  		
  		PreparedStatement prepStmt = conn.prepareStatement(sqlPatDelete);
  		
  		prepStmt.setString(1, patid);
  		
  		prepStmt.executeUpdate();
		prepStmt.close();
  	}
  	public void DeleteLocation(Connection conn) throws SQLException{
  		String locid;
  		
  		locid = JOptionPane.showInputDialog("Input Location ID to be Deleted: ");
  		
  		String sqlLocDelete = "DELETE * FROM locationdb WHERE locationid = ?";
  		
  		PreparedStatement prepStmt = conn.prepareStatement(sqlLocDelete);
  		
  		prepStmt.setString(1, locid);
  		
  		prepStmt.executeUpdate();
		prepStmt.close();
  	}
  	public void DeleteAppointment(Connection conn) throws SQLException{
  		String appid;
  		
  		appid = JOptionPane.showInputDialog("Input appointment ID to be Deleted: ");
  		
  		String sqlAppDelete = "DELETE * FROM appointmentdb WHERE appointmentid = ?";
  		
  		PreparedStatement prepStmt = conn.prepareStatement(sqlAppDelete);
  		
  		prepStmt.setString(1, appid);
  		
  		prepStmt.executeUpdate();
		prepStmt.close();
	}
	
	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		McCann_CC2 npc = new McCann_CC2();
		

	}

}
